// ── D98 §4–§5 · A RÉSUMÉ GENERATED ON THE PAGE — the extension's half (lane J6) ──────────────────────────────────────
//
// Owner, 10-13: "prepare and trigger a résumé generation for this job right on the page using the extension, view it,
// and include it in the autofill payload" — decided: option D of the sketch (docs/sketches/extension-onpage.html, tab 3):
// the in-page panel is the main path, the full editor opens only on demand.
//
// A Résumé panel in the on-page panel family (its own shadow root, the site's tokens, marks, both themes, no capsule):
//
//   Not generated ── Generate ──► Generating ──► Ready ──► Attach ──► Attached: FirstName_LastName_Company_Role.pdf
//        ▲                         │ Cancel       │ Regenerate (another slot, said first) · Edit in a full page
//        └── Try again ◄── Cancelled · Failed · Refused (the claim guard's reasons — NOTHING is attached)
//
// ⛔ THE EXTENSION NEVER CALLS A MODEL AND NEVER CALLS THE RÉSUMÉ SERVICE ITSELF. Every request below goes to draft's own server
//   through auth.js authedFetch (the extension's own token) — POST /api/extension/resume and its status / cancel / pdf
//   routes (routes/extensionResume.js). The server runs the web app's own generation: a Draft slot, the claim guard,
//   the ATS scorer, a normal tailored résumé linked to the job. test/j6ResumePanel.test.js greps every network target.
// ⛔ USER-TRIGGERED ONLY. A generation starts from ONE handler, RESUME_GENERATE — sent from the page's tab with
//   `trigger: "click"`; from anywhere but a web page's tab it is refused. ⭐ T22 REVISED (owner 10-15): the Résumé tab of
//   the dock is a VIEW (state, preview, Attach) and no longer starts one — its Generate / Try again / Regenerate are gone,
//   and so are the popup's "Résumé for this job" and every other trigger. The two places a résumé is started from are
//   the Draft button (T24) and the résumé field's row in a manual fill (T18's "Generate and attach") — both the user's
//   own press, both still to be wired; until then nothing in the extension sends RESUME_GENERATE. Nothing runs on a
//   timer, a page load, a step change or a fill. The popup's D23 rule holds: opening it reads nothing from the page.
// ⛔ NO MONEY, TOKENS, OR MODEL NAMES. The user sees the allowance ("uses 1 of your 10 Draft slots today") and nothing
//   else; the server already strips cost fields (services/extensionResume.js userSafe), and the model built here takes
//   only named fields from the server's answer, never echoes one wholesale.
// ⛔ THE PREVIEW CANNOT RUN OR LOAD ANYTHING. The server sends an allow-listed fragment (services/resumePreviewSanitiser.js);
//   here, as defence in depth, it is cleaned TWICE more — scrubPreviewHtml (text) before it leaves the service worker,
//   and in the page it is parsed by DOMParser (an inert document: no script runs, no image loads), every script,
//   embed, image, link and handler removed, every url() / @import removed, and only then moved into a shadow root of
//   its own, with the résumé's body{} rules mapped to :host.
// ⛔ A REFUSAL ATTACHES NOTHING. Attach is offered, and accepted by RESUME_ATTACH, only for a generation the server says
//   is `ready` — re-asked at the moment of the press, never taken from the panel's message.
// ⛔ NEVER A SILENT MISS. Attach sets the PDF on the page's upload control (DataTransfer, then input + change) and
//   VERIFIES the page shows the file's name; when it cannot be set or not verified — Workday's custom drop zone is the
//   likely case — the panel says so and offers Download PDF, copies the file name, and says "drag it onto the upload box".
//
// WHAT IS STORED, AND WHERE (for the privacy page, STORE_LISTING and PRIVACY_RECONCILIATION):
//   · NO NEW STORAGE KEY. The job's existing progress record (progress.js, chrome.storage.local `jobProgress`, 30 days,
//     cleared on Disconnect / sign-out / another account) gains a `resume` step: { at, id, status, attached } — the
//     generation's opaque id (erg_…), its last status word, when it started, and when Attach was pressed. No HTML, no
//     PDF, no file name, no score, no answer. The preview, the PDF and its name are asked of the server each time.
//   · The panel's own on-screen state (collapsed, which side) lives in the page's isolated world for the tab's life and
//     is not stored.
//
// Message handlers for the router (background.js — the coordinator wires them):
//   export const handlers = { RESUME_PANEL_OPEN, RESUME_GENERATE, RESUME_STATUS, RESUME_CANCEL, RESUME_ATTACH,
//                             RESUME_DOWNLOAD, RESUME_OPEN_EDITOR } — each async (msg, sender) => reply.
// configureResumePanel({ serverUrl }) sets the router's server URL (RESUME_MASTER_URL — draft's own server) once.

import { authedFetch } from './auth.js';
import { tabJob } from './answerMemory.js';
import { bindingForTab, bindingLabel } from './tabBinding.js';
import { lookupBoardJob } from './boardJob.js';
import { identifyAndBind, readFailurePopup } from './identify.js';
import { notePageRead } from './diagnostics.js';
import { overlayTheme, fetchPdf, formFrameOf } from './gated-handoff.js';
// ⭐ T17: the ATS and Résumé views are drawn on the dock, in the TOP frame.
import { drawInDock, dockMeta } from './dockHost.js';
import { noteResume, resumeFor } from './progress.js';
import { C_LIGHT } from './tokens.js';

let SERVER_URL = null;
/** The router's server URL (draft's own) — set once, at import, by background.js. */
export function configureResumePanel({ serverUrl } = {}) { SERVER_URL = serverUrl || null; }

/** The panel's poll while a generation runs (the server's own estimate is 10–20 s). */
export const POLL_MS = 2000;
/** ⚠ True at this lane's merge (D98 P3 not built — docs/D98_P0_REPORT.md §5): the web editor's save re-runs neither. */
export const EDIT_NOT_RECHECKED = 'Opens this job in draft in a new tab. Edits made there are not re-checked by the claim guard or re-scored yet.';
export const DRAG_HINT = 'drag it onto the upload box';

// ── the preview, cleaned as text (service worker side — it has no DOM) ───────────────────────────────────────────
/**
 * ⛔ Defence in depth on top of the server's allow-list: whatever arrives, nothing that can run or load leaves here.
 * Removed with their content: script, style-less embeds (iframe, object, embed, svg, math, template, noscript, video,
 * audio, canvas, form controls); removed as tags: img, picture, source, link, meta, base, input; every on…= handler,
 * src / srcset / href / action / background / poster attribute; every url(…), @import and expression(…) in CSS.
 */
export function scrubPreviewHtml(html) {
  let s = String(html ?? '').slice(0, 400_000);
  s = s.replace(/<!--[\s\S]*?-->/g, '');
  s = s.replace(/<(script|iframe|object|embed|svg|math|template|noscript|video|audio|canvas|form|button|select|textarea|frameset|frame|portal|applet)\b[\s\S]*?<\/\1\s*>/gi, '');
  s = s.replace(/<\/?(script|iframe|object|embed|svg|math|template|noscript|video|audio|canvas|form|button|select|textarea|frameset|frame|portal|applet|img|picture|source|link|meta|base|input|track|area)\b[^>]*>/gi, '');
  s = s.replace(/\s(on[a-z]+|src|srcset|href|xlink:href|action|formaction|background|poster|ping|data)\s*=\s*("[^"]*"|'[^']*'|[^\s>]+)/gi, '');
  s = s.replace(/@import[^;]*;?/gi, '').replace(/url\s*\([^)]*\)/gi, 'none').replace(/expression\s*\(/gi, '(')
    .replace(/(-moz-binding|behavior)\s*:[^;}"']*/gi, '').replace(/javascript:/gi, '');
  return s;
}

// ── the words — one model per state, built from named fields only ───────────────────────────────────────────────
const jobWords = (job) => bindingLabel(job || {});
const slotWords = (a) => {
  if (!a || !Number.isFinite(a.limit)) return 'Uses 1 of your Draft slots.';
  if (a.remaining <= 0) return `You have used all ${a.limit} of your Draft slots for now — they come back over 24 hours.`;
  return `Uses 1 of your ${a.limit} Draft slots today — ${a.remaining} left.`;
};
const n = (v) => (Number.isFinite(v) ? Math.round(v) : null);

/** "What we changed — 9 rewritten · 2 added · +16 job terms" (the D90 change set's summary). */
export function changesWords(changes) {
  const s = changes?.summary;
  if (!s) return null;
  if (s.identical) return 'What we changed — nothing: it reads as your résumé does.';
  const parts = [];
  if (s.rewritten > 0) parts.push(`${s.rewritten} rewritten`);
  if (s.added > 0) parts.push(`${s.added} added`);
  if (s.removed > 0) parts.push(`${s.removed} removed`);
  const terms = Array.isArray(s.termsGained) ? s.termsGained.length : 0;
  if (terms) parts.push(`+${terms} job term${terms === 1 ? '' : 's'}`);
  if (s.roleChanges > 0) parts.push(`${s.roleChanges} role title${s.roleChanges === 1 ? '' : 's'} changed`);
  return `What we changed — ${parts.join(' · ') || 'a few words'}`;
}

const plain = (v, max = 300) => String(v ?? '').replace(/\s+/g, ' ').trim().slice(0, max);
/** ⛔ Money, tokens or a model's name. A server sentence that names one is never shown — a fixed one is, instead. */
export const COST_WORDS = /\$\s?\d|\b(usd|cents?|tokens?|claude[\w-]*|gpt-?\d[\w.-]*|sonnet|opus|haiku|anthropic|openai|gemini|llm|credit balance|api key|billing|pric(e|ing))\b/i;
const UNAVAILABLE = 'Résumé generation is unavailable right now.';
const safe = (v, fallback = null, max = 400) => { const t = plain(v, max); return !t || COST_WORDS.test(t) ? fallback : t; };
// ⭐ T22 REVISED (owner 10-15): the Résumé tab is a VIEW — its state, a preview, Attach — and no longer a place to START a
// résumé. Generate, Try again and Regenerate are gone from it; a résumé is started from exactly two places, the Draft
// button and the résumé field's own row in a manual fill (T24 / T18 — RESUME_GENERATE below is the one start they use).
// ⭐ T26: each action is an ICON in the dock (extension/dock.js ICONS); its label is the button's name and tooltip.
const ACTION = {
  cancel: { role: 'cancel', label: 'Cancel', icon: 'close' },
  attach: { role: 'attach', label: 'Attach', primary: true, icon: 'attach' },
  attachAgain: { role: 'attach', label: 'Attach again', icon: 'attach' },
  // ⭐ 47a (owner 11-21, E4): View résumé — draft's own sandbox (the RM editor) with What we changed against the base and the job
  edit: { role: 'edit', label: 'View résumé', icon: 'edit' },
  download: { role: 'download', label: 'Download PDF', icon: 'download' },
  downloadPrimary: { role: 'download', label: 'Download PDF', primary: true, icon: 'download' },
  // D99: an unlinked tab's message is a button, not an instruction to go somewhere else
  readPage: { role: 'read', label: 'Read this page now', primary: true, icon: 'read' },
  // ⭐ 47a (owner 11-21, E2: "generate the resume then and there") — the start comes back to this tab, as ONE primary press:
  // the person's click → RESUME_GENERATE (the one start: the server's generation, the claim guard, the scorer). T22's
  // "a view only" is revised on the owner's word; nothing here starts on a load, a timer or a fill.
  generate: { role: 'generate', label: 'Tailor my résumé for this job', primary: true, icon: 'resume' },
  tryAgain: { role: 'generate', label: 'Try again', icon: 'resume' },
};

// ⭐ D99 J12 · ATS ON THE PAGE — draft's own report on the user's base résumé, for the tab's job, shown at once. A
// signed-in user is never sent to the free checker. The words are the web app's (shared/atsBands.js labels).
const BAND_WORDS = Object.freeze({ strong: ['Strong match', 'ok'], moderate: ['Moderate match', 'info'], weak: ['Weak match', 'warn'],
  not_enough_signal: ['Not enough signal', ''] });
/** The report block, from boardJob.js atsFacts() — or null (nothing is shown rather than a guess). */
export function reportModel(ats) {
  if (!ats || typeof ats !== 'object') return null;
  if (ats.state === 'no_base_resume') {
    return { state: 'no_base_resume', line: 'Add your résumé in draft to see how it scores for this job.',
      action: { role: 'add-resume', label: 'Add your résumé in draft' } };
  }
  if (ats.state === 'unavailable') return { state: 'unavailable', line: 'The ATS score is not available right now.' };
  if (ats.state !== 'ready') return null;
  const band = BAND_WORDS[Number.isFinite(ats.score) ? ats.band : 'not_enough_signal'] || BAND_WORDS.not_enough_signal;
  const list = (xs) => (Array.isArray(xs) ? xs.map(x => plain(x, 60)).filter(Boolean).slice(0, 12) : []);
  // T3: a page draft does not hold is scored against ITS OWN TEXT — said so, and there is no board report to open
  const fromPage = ats.basis === 'page';
  return { state: 'ready', head: Number.isFinite(ats.score) ? `ATS ${Math.round(ats.score)} · ${band[0]}` : `ATS · ${band[0]}`, tone: band[1],
    note: fromPage ? 'Your base résumé, scored against this page.' : 'Your base résumé, scored for this job.',
    matched: list(ats.matched), missing: list(ats.missing),
    // ⭐ T9: the scorer's own report (boardJob.js atsFacts, already kept to the component's named fields). When it is
    // here the panel draws THE web app's ATS report from it (the shared component), not the two lines above.
    report: ats.report && typeof ats.report === 'object' ? ats.report : null,
    // ⭐ 47a (owner 11-21, E1): THE ATS CARD (boardJob.js cardOf — the web's atsCardView words). When it is here the ATS tab
    // draws the card (the number, its four parts with their figures, the biggest gain), as the web's posting panel does.
    card: ats.card && typeof ats.card === 'object' ? ats.card : null,
    // ⭐ D105 P5: the report's terms that have a PUBLISHED Atlas page ({ base, slugs } — atlasForReport), or null.
    atlas: ats.atlas && typeof ats.atlas === 'object' && ats.atlas.slugs ? { base: String(ats.atlas.base || ''), slugs: ats.atlas.slugs } : null,
    action: fromPage ? null : { role: 'report', label: 'Full report in draft' } };
}

/**
 * The panel's model for one moment. Inputs:
 *   job        { jobId, title, company } — the tab's job (binding / released packet), or null
 *   view       GET /api/extension/resume/:id's answer, or null
 *   allowance  { used, limit, remaining } (the view's, else GET /api/draft/slots), or null
 *   error      { error, code } — a refused request's fixed sentence, or null
 *   attach     { outcome: 'attached' | 'fallback' | 'noinput', fileName, reason, base64? } — Attach's result, or null
 *   warning    the server's regenerate warning, or null
 * ⛔ Only these named fields are read; nothing of the server's answer is copied wholesale into what is shown.
 */
export function resumePanelModel(args = {}) {
  const m = modelCore(args);
  // T3: an unlinked tab still shows a score read from the page itself — never a board report for a job it is not on
  return { ...m, report: m.state === 'nojob' && args.report?.basis !== 'page' ? null : reportModel(args.report) };
}
function modelCore({ job = null, view = null, allowance = null, error = null, attach = null, warning = null } = {}) {
  const j = view?.job?.jobId ? { jobId: view.job.jobId, title: view.job.title ?? job?.title ?? null, company: view.job.company ?? job?.company ?? null } : job;
  const a = view?.allowance || allowance || null;
  const base = {
    id: view?.id && /^erg_[a-f0-9]{8,64}$/.test(view.id) ? view.id : null,
    job: j ? jobWords(j) : null,
    title: 'Résumé for this job', state: 'none', lines: [], reasons: [], findings: [], actions: [],
    progress: null, poll: false, preview: null, score: null, changes: null, guard: null, fileName: null, download: null,
    allowance: a ? { limit: n(a.limit), remaining: n(a.remaining) } : null,
  };
  const line = (text, tone = '') => base.lines.push({ text: plain(text, 400), tone });
  const refunded = view?.slot?.refunded === true;

  if (!j?.jobId) {
    return { ...base, state: 'nojob', title: 'Résumé for this job', job: null,
      lines: [{ text: 'This tab is not linked to a job yet — Read this page now finds it on your board.', tone: 'warn' }],
      actions: [ACTION.readPage] };
  }
  if (error && !view) {
    line(safe(error.error, UNAVAILABLE), 'warn');
    if (error.code === 'slots_exhausted') line(slotWords(a));
    return { ...base, state: 'error', actions: [] };
  }
  const status = view?.status || null;
  if (!status) {
    line('No résumé has been made for this job yet.');
    return { ...base, state: 'none', title: 'Résumé for this job', actions: [ACTION.generate] };
  }
  if (status === 'queued' || status === 'generating') {
    line(`Generating your résumé for ${jobWords(j)} — usually 10–20 seconds.`);
    line('You can close the draft popup or go to the next step; it keeps going.');
    if (safe(warning)) line(safe(warning), 'warn');
    return { ...base, state: 'generating', title: 'Generating…', poll: true, actions: [ACTION.cancel],
      progress: { startedAt: Number.isFinite(view.createdAt) ? view.createdAt * 1000 : Date.now(), label: status === 'queued' ? 'Waiting to start' : 'Generating' } };
  }
  if (status === 'refused') {
    const reasons = (view.guard?.reasons || []).map(r => safe(r)).filter(Boolean).slice(0, 12);
    line('draft withheld this résumé: it claimed something your profile does not support.', 'warn');
    line('Nothing was attached.');
    if (refunded) line('Your Draft slot was given back.');
    return { ...base, state: 'refused', title: 'Withheld by the claim guard', reasons, actions: [ACTION.tryAgain] };
  }
  if (status === 'failed') {
    line(safe(view.error?.message, UNAVAILABLE), 'warn');
    line(refunded ? 'Nothing was attached, and your Draft slot was given back.' : 'Nothing was attached.');
    return { ...base, state: 'failed', title: 'It did not finish', actions: [ACTION.tryAgain] };
  }
  if (status === 'cancelled') {
    line('Cancelled — nothing was attached.');
    line(refunded ? 'Your Draft slot was given back.' : 'The work had already started, so the slot was used.');
    return { ...base, state: 'cancelled', title: 'Cancelled', actions: [ACTION.tryAgain] };
  }
  // ready
  const ready = {
    ...base,
    preview: view.preview?.html ? { html: scrubPreviewHtml(view.preview.html) } : null,
    score: view.score && (Number.isFinite(view.score.before) || Number.isFinite(view.score.after)) ? { before: n(view.score.before), after: n(view.score.after) } : null,
    changes: changesWords(view.changes),
    guard: view.guard?.passed === true
      ? { text: 'Checked against your profile — nothing it claims goes beyond what your profile says.', tone: 'ok' }
      : null,
    findings: (view.guard?.findings || []).map(f => safe(f)).filter(Boolean).slice(0, 6),
    fileName: plain(attach?.fileName || view.pdf?.fileName || '', 120) || null,
  };
  const more = [];
  if (view.fromExisting) more.push({ text: 'No slot used — draft had already made this résumé for this job from your current résumé.', tone: '' });
  if (safe(warning)) more.push({ text: safe(warning), tone: 'warn' });
  const outcome = attach?.outcome || (view.pdf?.attached ? 'attached' : null);
  if (outcome === 'attached') {
    return { ...ready, state: 'attached', title: `Attached: ${ready.fileName || 'your résumé'}`,
      lines: [...more, attach ? { text: 'The page shows the file in its upload box.', tone: 'ok' }
        : { text: 'You chose this file for this application. If the upload box does not show it, press Attach again or Download PDF.', tone: '' },
        { text: 'A later fill on this application attaches this same file — nothing is generated again.', tone: '' }],
      actions: [ACTION.attachAgain, ACTION.download, ACTION.edit] };
  }
  if (outcome === 'fallback' || outcome === 'noinput') {
    const why = outcome === 'noinput'
      ? 'There is no upload box for a résumé on this step.'
      : `draft could not put the file in this page's upload box${attach?.reason === 'not_shown' ? ' — the page did not show its name' : ''}.`;
    return { ...ready, state: 'fallback', title: 'Attach it yourself', download: attach?.base64 ? { base64: attach.base64 } : null,
      lines: [...more, { text: why, tone: 'warn' },
        { text: `Download PDF — its name is copied for you — then ${DRAG_HINT}.`, tone: '' },
        ...(outcome === 'noinput' ? [{ text: 'Or press Attach again on the step that asks for your résumé.', tone: '' }] : [])],
      actions: [ACTION.downloadPrimary, ACTION.attachAgain, ACTION.edit] };
  }
  return { ...ready, state: 'ready', title: 'Your résumé is ready',
    lines: [...more, { text: 'Read it, then Attach puts it in this application’s upload box.', tone: '' }],
    actions: [ACTION.attach, ACTION.download, ACTION.edit] };
}

/** Every word a model shows the user — its title, lines, reasons, findings, buttons and marks (not the résumé itself). */
export function modelWords(m) {
  if (!m) return '';
  return [m.title, m.job, m.changes, m.guard?.text, m.fileName, m.progress?.label,
    ...(m.lines || []).map(l => l.text), ...(m.reasons || []), ...(m.findings || []), ...(m.actions || []).map(x => x.label),
    m.score ? `ATS ${m.score.before ?? '–'} → ${m.score.after ?? '–'}` : null,
    m.report?.head, m.report?.line, m.report?.note, m.report?.action?.label].filter(Boolean).join('\n');
}

// ── the injected views: the dock's ATS tab and Résumé tab ────────────────────────────────────────────────────────
// Runs in the page's ISOLATED world, TOP frame (it needs chrome.runtime to talk back). executeScript serialises it, so it
// closes over NOTHING: the model and the palettes arrive as arguments (extension/tokens.js — never a colour literal).
// ⭐ T17: TWO views of the dock (extension/dock.js) drawn from ONE model — the ATS tab (draft's report for the tab's job:
// T9's shared component when the scorer's report came with it) and the Résumé tab (the generation's state, its
// preview, Attach). The window they sit in — drag, resize, snap, collapse, Close, Esc, where it sits on this site — is
// the dock's, once; nothing here moves anything. Each view has its own shadow root: the page's CSS is kept out and its
// own in; the form probe never sees them (the dock is not in <body>). `meta.tab` says which tab to show ('ats' or
// 'resume', default 'resume').
// ⛔ D60: rectangles — controls radius 8 on 28+, marks radius 6 with a 3px leading bar, the bar square-ended (radius 1).
export function renderResumePanel(model, meta) {
  const ID = 'rm-resume-panel';
  const ATS_ID = 'rm-ats-panel';
  const D = globalThis.__draftDock;
  const dock = D?.ensure?.(meta?.dock || {}) || null;
  if (!dock) return { ok: false, rendered: false, error: D ? 'not_top_frame' : 'no_dock' };
  if (!model) {
    for (const [tab, id] of [['resume', ID], ['ats', ATS_ID]]) { const el = document.getElementById(id); if (el) dock.drop(tab, el); }
    return { ok: true, rendered: false, closed: true };
  }

  const theme = meta?.theme || {};
  const varsOf = (pal) => Object.entries(pal || {}).map(([k, v]) => `--c-${k.toLowerCase().replace(/_/g, '-')}: ${v};`).join(' ');
  const LOGO_FACE = 'rm-draft-logo';
  if (theme.logoFont && typeof FontFace === 'function') {
    try {
      const bin = atob(theme.logoFont);
      const bytes = new Uint8Array(bin.length);
      for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
      const face = new FontFace(LOGO_FACE, bytes.buffer, { style: 'italic', weight: '800' });
      document.fonts.add(face);
      face.load().catch(() => {});
    } catch { /* the fallback face carries the same words */ }
  }
  const logo = `'${LOGO_FACE}', 'Poppins', ui-sans-serif, system-ui, sans-serif`;
  const paper = meta?.paper || {};
  // ⭐ T26 (owner, 10-19): the résumé itself (the preview) and the numbers are what is on screen — the state, its lines,
  // the guard, the changes, the reasons are a screen reader's words (.sr) and the state mark's tooltip; the actions are
  // icons. ONE surface (the dock's frame — the view paints none), ONE accent, no rule, no tinted box.
  const css = `
    :host { all: initial; display: block; height: 100%; }
    .rp { ${varsOf(theme.light)} --c-paper: ${paper.bg || 'Canvas'}; --c-paper-ink: ${paper.ink || 'CanvasText'}; }
    @media (prefers-color-scheme: dark) { .rp { ${varsOf(theme.dark)} } }
    .rp { box-sizing: border-box; height: 100%; display: flex; flex-direction: column; overflow: hidden;
      font: 13px/1.45 'DM Sans', ui-sans-serif, system-ui, -apple-system, 'Segoe UI', sans-serif; color: var(--c-ink);
      background: transparent; text-align: left; }
    .rp * { box-sizing: border-box; }
    .sr { position: absolute !important; width: 1px !important; height: 1px !important; padding: 0 !important; margin: -1px !important;
      border: 0 !important; overflow: hidden; clip: rect(0 0 0 0); white-space: nowrap; }
    .ic { display: block; flex: none; }
    .hd { display: flex; align-items: center; gap: 12px; padding: 10px 14px 4px; font-size: 12px; font-weight: 800;
      font-variant-numeric: tabular-nums; color: var(--c-ink-muted); }
    .st { display: inline-grid; place-items: center; color: var(--c-ink-faint); }
    .st[data-tone="ok"] { color: var(--c-success); } .st[data-tone="warn"] { color: var(--c-warning); }
    .num { display: inline-flex; align-items: center; gap: 4px; }
    .t { font-family: ${logo}; font-style: italic; font-weight: 800; }
    .btn:focus-visible { outline: 2px solid var(--c-accent-ink); outline-offset: 2px; }
    .sc { overflow: auto; padding: 8px 14px; flex: 1; min-height: 0; display: grid; gap: 8px; align-content: start; }
    .ln { margin: 0; font-size: 12.5px; }
    .rpt { display: grid; gap: 6px; }
    /* ⭐ 47a E1 · the ATS card (the web's AtsCard.jsx): the number painted by band, four parts with a 6 px bar (2 px corner, D60),
       their line and figures, the biggest gain. No band word — the colour says it. */
    .ac { display: grid; gap: 12px; } .ac [data-band="strong"] { color: var(--c-band-strong); }
    .ac [data-band="moderate"] { color: var(--c-band-moderate); } .ac [data-band="weak"] { color: var(--c-band-weak); }
    .ac .big { font-size: 36px; font-weight: 800; line-height: 1; font-variant-numeric: tabular-nums; }
    .ac .fx { font-size: 11.5px; color: var(--c-ink-muted); overflow-wrap: anywhere; }
    .ac .pt { display: grid; grid-template-columns: minmax(64px, 84px) minmax(0, 1fr) 28px; gap: 10px; align-items: start; }
    .ac .pn { font-size: 12.5px; } .ac .pv { font-weight: 800; text-align: right; font-variant-numeric: tabular-nums; }
    .ac .bar { height: 6px; border-radius: 2px; background: var(--c-border); overflow: hidden; margin-top: 5px; }
    .ac .bar i { display: block; height: 6px; background: currentColor; }
    .ac .gn { border-top: 1px solid var(--c-border); padding-top: 10px; font-size: 12.5px; }
    .ac .pl { display: grid; gap: 6px; font-size: 12px; } .ac .pl .fl { color: var(--c-warning); }
    .ac .pl button { font: inherit; font-size: 11.5px; background: none; border: 0; padding: 0; color: var(--c-accent-ink); cursor: pointer; }
    .prog { display: inline-flex; align-items: center; gap: 8px; flex: 1; }
    .pb { flex: 1; min-width: 40px; height: 4px; border-radius: 1px; background: var(--c-surface-solid); overflow: hidden; position: relative; }
    .pb i { position: absolute; top: 0; bottom: 0; width: 34%; background: var(--c-accent); animation: rm-slide 1.4s ease-in-out infinite; }
    @keyframes rm-slide { from { left: -34%; } to { left: 100%; } }
    /* ⛔ D60 / D63 → ⭐ D152 (7b): a status is a MARK — a plain word (no box, bar, tint or heavy italic); a state a 6px dot
       before it, the word in muted ink. */
    .marks { display: flex; gap: 6px 14px; flex-wrap: wrap; }
    .mark { --mk: var(--c-ink-faint); display: inline-block; font-style: normal; font-weight: 500; font-size: 12.5px;
      line-height: 1.4; padding: 0; border-radius: 0; color: var(--mk); border: 0; background: none; }
    .mark.ok { --mk: var(--c-success); } .mark.warn { --mk: var(--c-warning); } .mark.no { --mk: var(--c-danger); } .mark.info { --mk: var(--c-info); }
    .mark:is(.ok, .warn, .no, .info) { color: var(--c-ink-muted); padding-left: 12px;
      background: radial-gradient(circle at 3px 50%, var(--mk) 3px, transparent 3.5px) no-repeat; }
    .list { margin: 0; padding: 0 0 0 16px; font-size: 12px; }
    .list li { margin: 0 0 3px; }
    .pvw { flex: 1; min-height: 200px; overflow: auto; border-radius: 6px; background: var(--c-paper); box-shadow: var(--c-depth-rest); }
    .pv { display: block; width: 816px; zoom: .42; background: var(--c-paper); color: var(--c-paper-ink); }
    .ft { padding: 8px 14px 12px; display: flex; align-items: center; gap: 8px; }
    .acts { display: flex; gap: 6px; flex-wrap: wrap; }
    /* ⛔ D60: a 30px icon control at radius 8. */
    .btn { width: 30px; height: 30px; padding: 0; display: inline-grid; place-items: center; flex: none; font: inherit; border-radius: 8px; border: 0;
      background: var(--c-surface-solid); color: var(--c-ink); box-shadow: var(--c-depth-rest); cursor: pointer;
      transition: box-shadow .2s ease, transform .2s ease; }
    .btn:hover:not(:disabled), .btn:focus-visible { box-shadow: var(--c-depth-hover); transform: translateY(-2px); }
    .btn:active:not(:disabled) { transform: translateY(0); box-shadow: var(--c-depth-press); }
    .btn:disabled { cursor: default; opacity: .45; box-shadow: none; }
    .btn.primary { background: var(--c-accent); color: var(--c-on-accent); box-shadow: var(--c-depth-accent); }
    .say { display: inline-grid; place-items: center; color: var(--c-ink-muted); }
    .say.warn { color: var(--c-warning); }
    .say:empty { display: none; }
    .empty { display: grid; justify-items: center; padding: 24px 0; color: var(--c-ink-faint); }
    @media (prefers-reduced-motion: reduce) { .btn { transition: none; } .pb i { animation: none; left: 0; width: 100%; } }
  `;
  const I = (name, size) => (typeof D.icon === 'function' ? D.icon(name, size) : '');
  const sr = (text, attrs = '') => `<span class="sr"${attrs}>${esc(text)}</span>`;
  /** An icon control: its label is its name and its tooltip. */
  const ibtn = (a) => `<button class="btn${a.primary ? ' primary' : ''}" data-role="${esc(a.role)}" aria-label="${esc(a.label)}" title="${esc(a.label)}">${I(a.icon || 'open')}</button>`;
  // the state as a shape: ready / attached ✓ · needs you ! · generating (pauses) · cancelled ∅ · nothing yet (the tab's icon)
  const STATE_ICON = { ready: ['check', 'ok'], attached: ['check', 'ok'], generating: ['wait', ''], none: ['resume', ''], cancelled: ['blank', ''],
    nojob: ['need', 'warn'], error: ['need', 'warn'], refused: ['need', 'warn'], failed: ['need', 'warn'], fallback: ['need', 'warn'] };

  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const send = (msg) => new Promise((resolve) => {
    try { chrome.runtime.sendMessage(msg, (reply) => { void chrome.runtime.lastError; resolve(reply ?? null); }); } catch { resolve(null); }
  });

  // ⛔ The preview, cleaned AGAIN in the page: an inert DOMParser document (nothing in it runs or loads), everything that
  // could run or load removed, then moved into a shadow root of its own. The résumé's html/body rules become :host.
  const cleanCss = (t) => String(t || '').replace(/\/\*[\s\S]*?\*\//g, '').replace(/@import[^;]*;?/gi, '').replace(/url\s*\([^)]*\)/gi, 'none')
    .replace(/expression\s*\(/gi, '(').replace(/(-moz-binding|behavior)\s*:[^;}]*/gi, '')
    .replace(/(^|[}\s,])(html|body)(?=[\s,{.:#[>~+])/gi, '$1:host');
  const DROP = 'script,style,iframe,object,embed,img,picture,source,video,audio,canvas,link,meta,base,svg,math,form,input,button,select,textarea,frame,frameset,template,noscript,portal,applet,track,area';
  const fillPreview = (el, html) => {
    const r = el.attachShadow({ mode: 'open' });
    const doc = new DOMParser().parseFromString(`<!doctype html><html><head></head><body>${html}</body></html>`, 'text/html');
    const styles = [...doc.querySelectorAll('style')].map(s => cleanCss(s.textContent)).join('\n');
    doc.querySelectorAll(DROP).forEach(n => n.remove());
    for (const n of doc.body.querySelectorAll('*')) {
      for (const at of [...n.attributes]) {
        const k = at.name.toLowerCase();
        if (k.startsWith('on') || ['src', 'srcset', 'href', 'xlink:href', 'action', 'formaction', 'background', 'poster', 'ping', 'data', 'target'].includes(k)) n.removeAttribute(at.name);
        else if (k === 'style') n.setAttribute('style', cleanCss(at.value));
      }
    }
    const st = document.createElement('style');
    st.textContent = `:host { display: block; padding: 24px 32px; } ${styles}`;
    const page = document.createElement('div');
    page.setAttribute('data-role', 'page');
    page.append(...[...doc.body.childNodes].map(c => document.importNode(c, true)));
    r.append(st, page);
  };

  // The two hosts, from the dock — fresh elements; the last draw's views are cleaned up and removed.
  const want = meta?.tab === 'ats' ? 'ats' : 'resume';
  let pollTimer = null;
  let tick = null;
  function cleanup() { clearTimeout(pollTimer); clearInterval(tick); }
  const atsHost = dock.view('ats', { id: ATS_ID, label: 'draft — ATS report for this job', expand: want === 'ats', select: want === 'ats', onClose: cleanup });
  atsHost.setAttribute('data-draft-ats-panel', '');
  const host = dock.view('resume', { id: ID, label: 'draft — résumé for this job', expand: want === 'resume', select: want === 'resume', onClose: cleanup });
  host.setAttribute('data-draft-resume-panel', '');
  const mount = (h, label) => {
    const r = h.attachShadow({ mode: 'open' });
    const style = document.createElement('style');
    style.textContent = css;
    const p = document.createElement('div');
    p.className = 'rp';
    p.setAttribute('role', 'region');
    p.setAttribute('aria-label', label);
    r.append(style, p);
    return { root: r, panel: p };
  };
  const { root, panel } = mount(host, 'draft — résumé for this job');
  const { root: atsRoot, panel: atsPanel } = mount(atsHost, 'draft — ATS report for this job');

  let m = model;
  const elapsed = (from) => { const s = Math.max(0, Math.round((Date.now() - from) / 1000)); return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`; };

  // ⭐ 47a (owner 11-21, E1) · "Does it add up?" — the base résumé's flags under the card (D192 (4d)), each with Dismiss
  // (the person's click; kept across re-scores). Asked of the service worker when the card is drawn; nothing is stored here.
  let flagsAsk = 0;
  function drawFlags() {
    const ask = ++flagsAsk;
    send({ type: 'RESUME_FLAGS' }).then((r) => {
      const box = atsRoot.querySelector('[data-role="plausibility"]');
      if (!box || ask !== flagsAsk) return;
      const flags = Array.isArray(r?.flags) ? r.flags : [];
      box.innerHTML = !flags.length ? '' : `<div class="pn"><b>Does it add up?</b></div>${flags.map((f, i) => `<div data-flag="${i}">
          <div class="fl">⚠ ${esc(f.company ? `${f.company}: ` : '')}${esc(f.bullet)}</div>
          <div class="fx">${esc(f.reason)}</div><button type="button" data-dismiss="${i}">Dismiss</button></div>`).join('')}`;
      box.querySelectorAll('[data-dismiss]').forEach((b) => b.addEventListener('click', async (e) => {
        if (!e.isTrusted) return;
        const f = flags[Number(b.dataset.dismiss)];
        b.disabled = true;
        const d = await send({ type: 'RESUME_FLAG_DISMISS', key: f?.key, trigger: 'click' });
        if (d?.ok) b.closest('[data-flag]')?.remove(); else b.disabled = false;
      }));
    });
  }

  // ── the ATS tab: draft's report for this tab's job ──
  const ACTIONS_READ = { role: 'read', label: 'Read this page now', primary: true, icon: 'read' };
  const drawAts = () => {
    atsHost.dataset.state = m.report?.state || (m.state === 'nojob' ? 'nojob' : 'none');
    dock.summary('ats', m.report?.head || 'ATS');   // what the slim bar says while this tab is shown
    // ⭐ T9: the shared ATS component (extension/atsReport.js, injected before this function by RESUME_PANEL_OPEN). A
    // content script's isolated world has no custom-element registry, so the view calls its renderer directly —
    // the same code, the same stylesheet, in a shadow root of its own inside this one.
    const ATS = globalThis.__draftAtsReport;
    const card = !!(m.report?.report && typeof ATS?.mountAtsReport === 'function');
    const nojob = !m.report && m.state === 'nojob';
    // ⭐ 47a (owner 11-21, E1): THE ATS CARD when the server sent the contextual block — the web's card, the same words
    // (boardJob.js cardOf ← shared/contextualView.js atsCardView); the older report stays the fallback for an older server.
    const ac = m.report?.card || null;
    const acHtml = !ac ? '' : ac.declined
      ? `<div class="ac" data-role="ats-card-view" data-declined=""><div class="pn"><b>Not enough signal</b></div><p class="fx">${esc(ac.reason)}</p></div>`
      : `<div class="ac" data-role="ats-card-view">
          <div class="big" data-role="ats-card-score" data-band="${esc(ac.band || '')}">${esc(ac.score)}%</div>
          ${ac.facts?.length ? `<div class="fx" data-role="ats-card-facts">${esc(ac.facts.join(' · '))}</div>` : ''}
          ${(ac.parts || []).map(p => `<div class="pt" data-ats-part="${esc(p.id)}"><div class="pn">${esc(p.name)}</div>
            <div><div class="bar" aria-hidden="true" data-band="${esc(p.band || '')}"><i style="width:${Number(p.score) || 0}%"></i></div>
              ${p.line ? `<div class="fx">${esc(p.line)}</div>` : ''}${p.facts?.length ? `<div class="fx">${esc(p.facts.join(' · '))}</div>` : ''}</div>
            <div class="pv" data-band="${esc(p.band || '')}">${esc(p.score)}</div></div>`).join('')}
          ${ac.gain ? `<div class="gn" data-role="ats-card-gain">Biggest gain: ${esc(ac.gain.text)}</div>` : ''}
          <div class="pl" data-role="plausibility"></div>
        </div>`;
    // ⭐ T26: the title and the job are hidden words; the report (T9's shared component, or its summary marks) is the view
    atsPanel.innerHTML = `
      <div class="hd">
        <div class="t sr" data-role="title">ATS for this job</div>
        ${m.job ? `<div class="s sr" data-role="job">${esc(m.job)}</div>` : ''}
      </div>
      <div class="sc">
        ${m.report ? `<div class="rpt" data-role="ats-report" data-state="${esc(m.report.state)}">${
          // ⭐ T9: THE web app's ATS report — the shared component, mounted below into its own shadow root — when the
          // scorer's report came with the answer and the component was injected; else the summary lines, as before.
          ac ? acHtml : card ? '<div data-role="ats-card"></div>' : `${
          m.report.head ? `<div class="marks"><span class="mark ${esc(m.report.tone || '')}" data-role="ats-score">${esc(m.report.head)}</span></div>` : ''}${
          m.report.matched?.length ? `<p class="ln" data-role="ats-matched"><b>Matched:</b> ${esc(m.report.matched.join(', '))}</p>` : ''}${
          m.report.missing?.length ? `<p class="ln" data-role="ats-missing"><b>Missing:</b> ${esc(m.report.missing.join(', '))}</p>` : ''}`}${
          m.report.note ? `<p class="note sr">${esc(m.report.note)}</p>` : ''}${
          m.report.line ? `<p class="ln sr">${esc(m.report.line)}</p>` : ''}${
          m.report.action ? `<div class="acts">${ibtn({ role: m.report.action.role, label: m.report.action.label, icon: 'open' })}</div>` : ''}
        </div>` : nojob ? `<div class="empty" title="${esc((m.lines || []).map(l => l.text).join(' ') || 'Read this page')}">${I('read', 28)}${(m.lines || []).map(l => `<p class="ln sr ${esc(l.tone)}">${esc(l.text)}</p>`).join('')}`
          + `<div class="acts">${ibtn(ACTIONS_READ)}</div></div>`
          : `<div class="empty" title="No ATS report for this job yet.">${I('ats', 28)}<p class="ln sr" data-role="ats-none">No ATS report for this job yet.</p></div>`}
        ${m.job ? `<div class="acts">${ibtn({ role: 'unbind', label: `Unlink this page from ${m.job}`, icon: 'unlink' })}</div>` : ''}
        <div class="say" data-role="say" aria-live="polite"></div>
      </div>`;
    if (ac) drawFlags();
    if (card && !ac) { const cardHost = atsRoot.querySelector('[data-role="ats-card"]'); try { ATS.mountAtsReport(cardHost, m.report.report, m.report.atlas ? { atlas: m.report.atlas } : {}); } catch { cardHost?.remove(); } }
  };

  // ── the Résumé tab: the generation's state, a preview, Attach ──
  const draw = () => {
    host.dataset.state = m.state;
    host.dataset.id = m.id || '';
    dock.summary('resume', `Résumé · ${m.state === 'generating' ? 'generating…' : m.state === 'attached' ? 'attached' : m.state === 'ready' ? 'ready' : m.title}`);
    // ⭐ T26: every line is a hidden word and the state mark's tooltip; on screen: the state's shape, the score and the
    // elapsed time as numbers, the preview, the actions as icons.
    const lines = (m.lines || []).map(l => `<p class="ln sr ${esc(l.tone)}">${esc(l.text)}</p>`).join('');
    const [stIcon, stTone] = STATE_ICON[m.state] || ['resume', ''];
    const tip = [m.title, m.job, ...(m.lines || []).map(l => l.text), m.guard?.text, m.changes].filter(Boolean).join(' · ');
    const prog = m.progress ? `<div class="prog" data-role="progress"><span class="sr">${esc(m.progress.label)}</span><span data-role="elapsed">${elapsed(m.progress.startedAt)}</span>
      <div class="pb" aria-hidden="true"><i></i></div></div>` : '';
    const marks = [];
    if (m.score) marks.push(`<span class="sr" data-role="score">ATS ${esc(m.score.before ?? '–')} → ${esc(m.score.after ?? '–')}</span><span class="num" aria-hidden="true" title="ATS ${esc(m.score.before ?? '–')} → ${esc(m.score.after ?? '–')}">${I('ats', 14)}${esc(m.score.before ?? '–')}→${esc(m.score.after ?? '–')}</span>`);
    if (m.state === 'attached') marks.push('<span class="sr" data-role="attached-mark">attached ✓</span>');
    if (m.state === 'refused') marks.push('<span class="sr">withheld — nothing attached</span>');
    const reasons = m.reasons?.length ? `<ul class="list sr" data-role="reasons">${m.reasons.map(r => `<li>${esc(r)}</li>`).join('')}</ul>` : '';
    const findings = m.findings?.length ? `<div class="sr">Worth a look:</div><ul class="list sr" data-role="findings">${m.findings.map(r => `<li>${esc(r)}</li>`).join('')}</ul>` : '';
    const actions = (m.actions || []).map(ibtn).join('');
    const showsEdit = (m.actions || []).some(a => a.role === 'edit');
    const tipAll = [tip, ...(m.reasons || []), ...(m.findings || [])].filter(Boolean).join(' · ');
    panel.innerHTML = `
      <div class="hd">
        <span class="st" data-role="state-mark"${stTone ? ` data-tone="${stTone}"` : ''} title="${esc(tipAll)}" aria-hidden="true">${I(stIcon, 18)}</span>
        <div class="t sr" data-role="title">${esc(m.title)}</div>
        ${m.job ? `<div class="s sr" data-role="job">${esc(m.job)}</div>` : ''}
        ${marks.join('')}${prog}
      </div>
      <div class="sc">
        ${lines}
        ${m.changes ? `<p class="ln sr" data-role="changes">${esc(m.changes)}</p>` : ''}
        ${m.guard ? `<div class="guard sr" data-role="guard">${esc(m.guard.text)}</div>` : ''}
        ${findings}${reasons}
        ${m.preview ? '<div class="pvw" data-role="preview-wrap"><div class="pv" data-role="preview"></div></div>'
          : `<div class="empty" aria-hidden="true">${I(stIcon === 'check' ? 'resume' : stIcon, 28)}</div>`}
      </div>
      <div class="ft">
        <div class="acts">${actions}</div>
        ${showsEdit ? `<div class="note sr" data-role="edit-note">${esc(meta?.editNote || '')}</div>` : ''}
        <div class="say" data-role="say" aria-live="polite"></div>
      </div>`;
    if (m.preview?.html) { const pv = root.querySelector('[data-role="preview"]'); try { fillPreview(pv, m.preview.html); } catch { pv.textContent = 'The preview could not be shown.'; } }
    drawAts();
  };

  // ⭐ T26: what a press says is an icon — its words its tooltip and, for a screen reader, its text (T27: the popups)
  const sayIn = (r, text, warn = false) => { const el = r.querySelector('[data-role="say"]'); if (el) { el.className = `say${warn ? ' warn' : ''}`; el.title = text;
    el.innerHTML = `${I(warn ? 'need' : 'info')}<span class="sr"></span>`; el.lastChild.textContent = text; } };
  const schedule = () => {
    clearTimeout(pollTimer); clearInterval(tick);
    if (m.progress) tick = setInterval(() => { const e = root.querySelector('[data-role="elapsed"]'); if (e) e.textContent = elapsed(m.progress.startedAt); }, 1000);
    if (!m.poll || !m.id) return;
    pollTimer = setTimeout(async () => {
      if (!host.isConnected) return;
      const reply = await send({ type: 'RESUME_STATUS', id: m.id });
      if (!host.isConnected) return;
      if (reply?.model) { m = { ...reply.model, report: reply.model.report ?? m.report }; draw(); }
      schedule();
    }, meta?.pollMs || 2000);
  };
  // ⭐ T32: a read that did not find the job raises ITS popup (the reason, its code, the one fix) — never the panel's "!".
  // The popup's buttons act inside the person's own click: Allow / Capture / Draft / Sign in through DOCK_ACT, Details
  // through OPEN_SETTINGS, Retry reads again.
  const readPage = async (r) => {
    const reply = await send({ type: 'RESUME_READ_PAGE', trigger: 'click' });
    if (reply?.ok || !reply?.popup || !globalThis.__draftPopups?.show) return take(r, reply, 'Could not reach draft — try again.');
    if (reply.model) { m = { ...reply.model, report: reply.model.report ?? (reply.model.state === 'nojob' ? null : m.report) }; }
    draw(); schedule();
    const answer = await globalThis.__draftPopups.show({ ...reply.popup, theme: meta?.theme });
    if (!answer?.trusted) return;
    if (answer.action === 'retry') return readPage(r);
    if (answer.action === 'details') { void send({ type: 'OPEN_SETTINGS', trigger: 'click', section: 'details' }); return; }
    if (['allow-site', 'capture', 'draft', 'sign-in'].includes(answer.action)) void send({ type: 'DOCK_ACT', act: answer.action, trigger: 'click' });
  };
  const take = (r, reply, fallback) => {
    // the report is asked for when the panel opens; a later model (a status, a cancel) keeps it
    if (reply?.model) m = { ...reply.model, report: reply.model.report ?? (reply.model.state === 'nojob' ? null : m.report) };
    draw(); schedule();
    if (!reply?.ok) sayIn(r, reply?.message || fallback, true);
  };

  const download = async (r) => {
    const name = m.fileName || 'resume.pdf';
    let copied = false;
    try { await navigator.clipboard.writeText(name); copied = true; } catch { /* said below */ }
    let b64 = m.download?.base64 || null;
    if (!b64) {
      const got = await send({ type: 'RESUME_DOWNLOAD', id: m.id });
      b64 = got?.base64 || null;
      if (!b64) { sayIn(r, got?.message || 'The PDF could not be downloaded right now — try again.', true); return; }
    }
    const bin = atob(b64);
    const bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    const url = URL.createObjectURL(new Blob([bytes], { type: 'application/pdf' }));
    const a = document.createElement('a');
    a.href = url; a.download = name; a.style.display = 'none';
    r.append(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 30000);
    host.dataset.downloaded = name;
    sayIn(r, `Downloaded ${name}${copied ? ' — its name is copied' : ''}. Now ${meta?.dragHint || 'drag it onto the upload box'}.`);
  };

  const onClick = (r) => async (ev) => {
    const btn = ev.target.closest('button');
    if (!btn) return;
    const role = btn.dataset.role;
    // ⛔ Everything here reaches draft's server or the page: a page script's synthetic click is never enough.
    if (!ev.isTrusted) return;
    if (role === 'download') return download(r);
    btn.disabled = true;
    const say = (t, w) => sayIn(r, t, w);
    // ⭐ 47a E2 (owner 11-21): Tailor / Try again — the person's trusted click is the one start (RESUME_GENERATE, trigger 'click').
    if (role === 'generate') { say('Tailoring your résumé…'); return take(r, await send({ type: 'RESUME_GENERATE', trigger: 'click' }), 'Could not start — try again.'); }
    if (role === 'cancel') { say('Cancelling…'); return take(r, await send({ type: 'RESUME_CANCEL', id: m.id }), 'Could not cancel — try again.'); }
    if (role === 'attach') { say('Attaching…'); return take(r, await send({ type: 'RESUME_ATTACH', id: m.id }), 'Could not attach — try Download PDF.'); }
    if (role === 'edit') { const got = await send({ type: 'RESUME_OPEN_EDITOR', id: m.id }); btn.disabled = false; if (!got?.ok) say(got?.message || 'Could not open draft.', true); else say('Opened in a new tab.'); }
    if (role === 'read') { say('Reading this page…'); return readPage(r); }
    // ⭐ T31: "Unlink this page" — off the retired toolbar popup, here where the tab's job is named: forget which job this
    // tab is on (DOCK_ACT unbind — this tab, the person's own click)
    if (role === 'unbind') {
      const got = await send({ type: 'DOCK_ACT', act: 'unbind', trigger: 'click' });
      btn.disabled = false;
      say(got?.ok ? 'Unlinked — this page is not tied to a job any more.' : 'Could not unlink this page.', !got?.ok);
      return;
    }
    if (role === 'report' || role === 'add-resume') {
      const got = await send({ type: 'RESUME_OPEN_REPORT', to: role === 'report' ? 'report' : 'resume' }); btn.disabled = false;
      if (!got?.ok) say(got?.message || 'Could not open draft.', true); else say('Opened in a new tab.');
    }
  };

  host.__draftCleanup = cleanup;
  atsHost.__draftCleanup = () => {};
  root.addEventListener('click', (ev) => { void onClick(root)(ev); });
  atsRoot.addEventListener('click', (ev) => { void onClick(atsRoot)(ev); });
  draw();
  schedule();
  dock.restorePops?.('resume');
  dock.restorePops?.('ats');
  return { ok: true, rendered: true, state: m.state, tab: want };
}

// ── the injected attach ────────────────────────────────────────────────────────────────────────────────────────
/**
 * Injected, ISOLATED world. `file`: { probe: true } only looks; { base64, fileName, mimeType } sets the PDF on the page's
 * résumé upload — an input[type=file] that accepts a PDF, the résumé's by its own words (resumeInputScore, as the fill
 * picks it), else the lone unnamed one — then `input` and `change`, and VERIFIES: the page shows the file's name (a
 * Workday drop zone's "… Successfully Uploaded!"), or the input is the browser's own visible control (which draws the
 * name itself). Anything else is not verified, and the panel falls back to Download PDF. Never a cover letter's box.
 * → { target, set, verified, how: 'page' | 'native' | null, reason, field }
 */
export async function attachResumeFile(file) {
  // ⛔ BYTE-IDENTICAL (modulo indentation) TO gated-handoff.js's exported resumeInputScore — asserted by test.
  function resumeInputScore(context) {
    const t = String(context || '').toLowerCase();
    if (/cover[\s_-]*letter|motivation|transcript|portfolio|writing sample|photo|headshot|certificat|reference|supporting|additional/.test(t)) return -1;
    if (/r[ée]sum[ée]|\bcv\b|curriculum vitae/.test(t)) return 2;
    return 0;
  }
  const sleep = (ms) => new Promise(r => setTimeout(r, ms));
  const acceptsPdf = (el) => {
    const acc = String(el.getAttribute('accept') || '').toLowerCase().split(',').map(s => s.trim()).filter(Boolean);
    return !acc.length || acc.some(a => a === '.pdf' || a === 'application/pdf' || a === '*/*' || a === 'application/*');
  };
  // ⭐ LIVE (Greenhouse, measured 10-15): the input sits FIVE boxes below its upload group (div › .secondary-button ›
  // .button-container › .file-upload__wrapper › .file-upload[role=group]) — four steps up from its parent never reached
  // the group, where the page writes the chosen file's name. The upload's own group is the wrap.
  const wrapOf = (el) => el.closest('[data-automation-id^="formField"], [data-automation-id="file-upload-drop-zone"], .field, .application-question, fieldset, .file-upload, [role="group"]') || el.parentElement;
  const contextOf = (el) => {
    const own = el.id ? document.querySelector(`label[for="${CSS.escape(el.id)}"]`)?.textContent : '';
    const labelled = (el.closest('[aria-labelledby]')?.getAttribute('aria-labelledby') || '').split(/\s+/).map(id => document.getElementById(id)?.textContent || '').join(' ');
    const wrap = el.closest('[data-automation-id^="formField"], .field, .application-question, fieldset');
    const wrapLabel = wrap?.querySelector('label, legend, h3, h4, .ws-glabel')?.textContent || '';
    return [own, el.closest('label')?.textContent, el.getAttribute('aria-label'), el.name, el.id, el.getAttribute('data-automation-id'), labelled, wrapLabel]
      .filter(Boolean).join(' ');
  };
  const inputs = [...document.querySelectorAll('input[type="file"]')].filter(el => !el.disabled && acceptsPdf(el))
    .map(el => ({ el, score: resumeInputScore(contextOf(el)) }));
  const named = inputs.filter(i => i.score === 2);
  const neutral = inputs.filter(i => i.score === 0);
  // ⭐ T18: the review row names ITS upload (`file.target`: the probe's id / name, and the row's type). That upload is
  // taken only when it is still a PDF upload on the page and — for a résumé — not a box whose words say it is something
  // else (a cover letter's). A cover letter goes only into a box the row typed `cover_letter`.
  const t = file?.target || null;
  const targeted = t && (t.id || t.name) ? inputs.find(i => (t.id && i.el.id === t.id) || (!t.id && t.name && i.el.name === t.name)) : null;
  const byTarget = targeted && (t.kind === 'cover_letter' || targeted.score >= 0) ? targeted : null;
  const pick = byTarget || (t?.kind === 'cover_letter' ? null : named[0] || (neutral.length === 1 ? neutral[0] : null));
  const reason = pick ? null : !inputs.length ? 'no_file_input' : neutral.length > 1 ? 'ambiguous_file_inputs' : 'no_resume_input';
  const field = pick ? contextOf(pick.el).replace(/\s+/g, ' ').trim().slice(0, 80) : null;
  if (file?.probe || !pick) return { target: !!pick, set: false, verified: false, how: null, reason, field };

  const el = pick.el;
  try {
    const bin = atob(file.base64);
    const bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    const dt = new DataTransfer();
    dt.items.add(new File([bytes], file.fileName, { type: file.mimeType || 'application/pdf' }));
    el.files = dt.files;
    el.dispatchEvent(new Event('input', { bubbles: true, composed: true }));
    el.dispatchEvent(new Event('change', { bubbles: true, composed: true }));
  } catch (e) {
    return { target: true, set: false, verified: false, how: null, reason: 'not_set', field };
  }
  const isSet = () => !!(el.files && el.files.length === 1 && el.files[0].name === file.fileName);
  const shownByPage = () => {
    for (let n = wrapOf(el), up = 0; n && up < 4; n = n.parentElement, up++) {
      if (String(n.innerText || n.textContent || '').includes(file.fileName)) return true;
    }
    return false;
  };
  const nativeVisible = () => {
    const cs = getComputedStyle(el);
    const r = el.getBoundingClientRect();
    return r.width >= 40 && r.height >= 10 && cs.visibility !== 'hidden' && cs.display !== 'none' && Number(cs.opacity) > 0.5;
  };
  const t0 = Date.now();
  let how = null;
  // ⭐ (open item 2) Look AFTER the last wait, not only before it: the loop used to stop on the clock without looking again,
  // so on a busy machine — one 100 ms sleep returning seconds late, while the page drew the name — an attach the page
  // showed was called "not shown" and the panel fell back to Download PDF. Now the deadline is checked only after a look.
  for (;;) {
    if (shownByPage()) { how = 'page'; break; }
    if (isSet() && nativeVisible()) { how = 'native'; break; }
    if (Date.now() - t0 >= 2500) break;
    await sleep(100);
  }
  const set = isSet() || how === 'page';
  return { target: true, set, verified: !!how, how, reason: how ? null : set ? 'not_shown' : 'not_set', field };
}

// ── the service worker's side ──────────────────────────────────────────────────────────────────────────────────
// ⭐ D105 P5 · LINKS IN: which of the report's skill / quality terms have a PUBLISHED Atlas page — asked of draft's
// public GET /api/atlas/resolve (no credentials: it is public, and nothing of the user's goes with it), cached in the
// worker for its life (a term is asked once). A term absent from the answer, or any failure, draws no link — never a
// dead one. Verbs are not Atlas pages and are not asked.
const ATLAS_SLUGS = new Map();   // term → slug | null
const ATLAS_SLUG_RE = /^[a-z0-9]+(?:-[a-z0-9]+)*$/;
export async function atlasForReport(serverUrl, report, { fetchImpl = globalThis.fetch } = {}) {
  if (!serverUrl || !report || typeof report !== 'object') return null;
  // The shared model's own list (the bundle boardJob.js imports) — the same boxes the web app links.
  const terms = (globalThis.__draftAtsReport?.atlasTerms?.(report) || []).slice(0, 100);
  const ask = terms.filter(t => !ATLAS_SLUGS.has(t));
  if (ask.length) {
    try {
      const res = await fetchImpl(`${serverUrl}/api/atlas/resolve?terms=${encodeURIComponent(ask.join(','))}`, { credentials: 'omit' });
      if (res?.ok) {
        const got = (await res.json().catch(() => ({})))?.slugs || {};
        for (const t of ask) ATLAS_SLUGS.set(t, typeof got[t] === 'string' && ATLAS_SLUG_RE.test(got[t]) && got[t].length <= 80 ? got[t] : null);
      }
    } catch { /* no answer → no links */ }
  }
  const slugs = {};
  for (const t of terms) { const s = ATLAS_SLUGS.get(t); if (s) slugs[t] = s; }
  return Object.keys(slugs).length ? { base: `${serverUrl}/atlas/`, slugs } : null;
}
/** Test seam: forget the worker's Atlas answers. */
export function _resetAtlasSlugs() { ATLAS_SLUGS.clear(); }

const json = (serverUrl, path, init) => authedFetch(serverUrl, path, init)
  .then(async (res) => (res ? { ok: res.ok, status: res.status, body: await res.json().catch(() => ({})) } : { ok: false, status: 401, body: { error: 'Sign in to draft first.', code: 'not_signed_in' } }))
  .catch(() => ({ ok: false, status: 0, body: { error: 'Could not reach draft.', code: 'unreachable' } }));
const post = (serverUrl, path, body) => json(serverUrl, path, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body || {}) });
const ID_RE = /^erg_[a-f0-9]{8,64}$/;
const viewPath = (id) => `/api/extension/resume/${encodeURIComponent(id)}`;
/** ⭐ T18: the account's base résumé as a PDF (routes/extensionResume.js) — and whether there is one. */
export const BASE_RESUME_PDF = '/api/extension/base-resume/pdf/file';
export const BASE_RESUME_INFO = '/api/extension/base-resume';

async function activeTab() {
  try { return (await chrome.tabs.query({ active: true, currentWindow: true }))[0] || null; } catch { return null; }
}

/** The tab's job: its released packet, else its binding (answerMemory.js tabJob — one rule), with the binding's words. */
async function jobOfTab(tab) {
  const j = await tabJob(tab).catch(() => ({ jobId: null }));
  if (j?.jobId == null) return null;
  const b = await bindingForTab(tab).catch(() => null);
  const same = b && String(b.jobId) === String(j.jobId);
  return { jobId: String(j.jobId), title: same ? b.title : null, company: (same ? b.company : null) || j.company || null };
}

async function allowanceNow(serverUrl) {
  const r = await json(serverUrl, '/api/draft/slots');
  return r.ok ? { used: r.body.used, limit: r.body.limit, remaining: r.body.remaining } : null;
}

/** The view of THIS tab's job's generation, or null — the id is the tab's own record's, never the message's alone. */
async function currentView(serverUrl, job) {
  const rec = await resumeFor(job?.jobId);
  if (!rec?.id) return { rec: null, view: null };
  const r = await json(serverUrl, viewPath(rec.id));
  if (r.ok && r.body?.id === rec.id) { if (r.body.status !== rec.status) await noteResume(job.jobId, { status: r.body.status }); return { rec, view: r.body }; }
  return { rec, view: null, error: r.status === 404 ? null : r.body };
}

/**
 * ⭐ T9 · the web app's ATS component (extension/atsReport.js — shared/atsReportElement.js, bundled) goes into the
 * page's isolated world before a model that carries a report is drawn. A file of the extension's own (no remote code),
 * injected only when there is a report to draw; if it cannot be, the panel shows the summary lines, as before.
 */
async function withAtsComponent(tab, model) {
  if (model?.report?.report && tab?.id != null) {
    try { await chrome.scripting.executeScript({ target: { tabId: tab.id, frameIds: [0] }, files: ['atsReport.js'] }); } catch { /* the summary stands */ }
  }
  return model;
}

/** ⭐ T18: the upload a review row names — its id / name and type, nothing else of the message is trusted. */
const targetOf = (msg) => {
  const t = msg?.target;
  if (!t || typeof t !== 'object') return null;
  const s = (v) => (typeof v === 'string' && v.length <= 200 ? v : null);
  return { id: s(t.id), name: s(t.name), kind: ['resume', 'cover_letter', 'other'].includes(t.kind) ? t.kind : 'resume' };
};
/** attachResumeFile, injected into the tab's FORM frame (the top frame until a fill found the form elsewhere). */
async function injectAttach(tabId, args) {
  return (await chrome.scripting.executeScript({ target: { tabId, frameIds: [formFrameOf(tabId)] }, func: attachResumeFile, args: [args] }))?.[0]?.result || null;
}

const meta = async () => ({ theme: await overlayTheme(), paper: { bg: C_LIGHT.SURFACE_SOLID, ink: C_LIGHT.INK },
  pollMs: POLL_MS, editNote: EDIT_NOT_RECHECKED, dragHint: DRAG_HINT });

/** The router's handlers. `serverUrl` defaults to the one configureResumePanel set. */
export function handlersFor(serverUrl = null) {
  const url = () => serverUrl || SERVER_URL;
  // The PAGE a panel message came from — a web page's tab. The popup has no tab; the extension's own pages (Options)
  // have one, but it is not an application page, so neither counts as "the panel's click".
  const tabOf = (sender) => (sender?.tab?.id != null && /^https?:/.test(String(sender.tab.url || '')) ? sender.tab : null);
  const refuse = (message, extra = {}) => ({ ok: false, message, ...extra });
  /** D99 J12: draft's report for the tab's job — asked of draft's server each time the panel opens, never stored. */
  const reportFor = async (job) => {
    if (!job?.jobId || !url()) return null;
    const found = await lookupBoardJob(url(), job.jobId).catch(() => null);
    if (!found?.ok || !found.ats) return null;
    const atlas = found.ats.report ? await atlasForReport(url(), found.ats.report).catch(() => null) : null;
    return atlas ? { ...found.ats, atlas } : found.ats;
  };

  /** The tab's job and the generation the message names — which must be the tab's own job's current one. */
  async function scope(msg, sender) {
    const tab = tabOf(sender);
    if (!tab) return { error: refuse('Open the résumé panel on the application page.') };
    if (!url()) return { error: refuse('Not configured.') };
    const job = await jobOfTab(tab);
    if (!job) return { error: { ok: false, message: 'This tab is not linked to a job.', model: resumePanelModel({}) } };
    const { rec, view, error } = await currentView(url(), job);
    if (msg?.id != null && (!ID_RE.test(String(msg.id)) || rec?.id !== msg.id)) return { error: refuse('That is not this job’s résumé.', { model: resumePanelModel({ job, view, error }) }) };
    return { tab, job, rec, view, error };
  }

  const api = {
    /** Open (or refresh) the ATS and Résumé tabs — from Open dock / the context menu (the active tab), the dock's own tab
     *  press, or the review row's "See the Résumé tab". Starts nothing. */
    // ⭐ T17: the dock's ATS and Résumé tabs (`msg.tab`: 'ats' | 'resume' — which one to show), drawn in the TOP frame.
    RESUME_PANEL_OPEN: async (msg, sender) => {
      if (!url()) return refuse('Not configured.');
      const tab = tabOf(sender) || await activeTab();
      if (!tab?.id) return refuse('Open the application page first.');
      const job = await jobOfTab(tab);
      const { view, error } = job ? await currentView(url(), job) : { view: null };
      const allowance = job && !view ? await allowanceNow(url()) : null;
      const model = resumePanelModel({ job, view, allowance, error, report: await reportFor(job) });
      await withAtsComponent(tab, model);
      try {
        const r = await drawInDock(tab.id, renderResumePanel, [model, { ...(await meta()), dock: await dockMeta(tab), tab: msg?.tab === 'ats' ? 'ats' : 'resume' }]);
        return { ok: !!r?.rendered, state: model.state };
      } catch (e) {
        // No grant for this tab (the popup was not opened on it), or a page that takes no script (chrome://, a PDF).
        return refuse("draft can't draw the résumé panel on this page.", { reason: String(e?.message || e).slice(0, 160) });
      }
    },

    /**
     * ⛔ The ONE start — a click from the page's tab, never the popup. ⭐ T22 REVISED: no control sends it yet; T24 (the
     * Draft button) and T18 (the résumé row's "Generate and attach") are the two that will.
     */
    RESUME_GENERATE: async (msg, sender) => {
      if (msg?.trigger !== 'click') return refuse('A résumé is generated only from its button.');
      const tab = tabOf(sender);
      if (!tab) return refuse('Generate from the résumé panel on the application page.');
      if (!url()) return refuse('Not configured.');
      const job = await jobOfTab(tab);
      if (!job) return { ok: false, model: resumePanelModel({}) };
      const regenerate = msg.regenerate === true;
      const r = await post(url(), '/api/extension/resume', { boundJobId: job.jobId, trigger: 'click', ...(regenerate ? { regenerate: true } : {}),
        ...(msg.reuseOnly === true && !regenerate ? { reuseOnly: true } : {}) });
      if (!r.ok || !ID_RE.test(String(r.body?.id || ''))) {
        return { ok: false, message: r.body?.error || 'Résumé generation is unavailable right now.', model: resumePanelModel({ job, error: r.body, allowance: r.body?.allowance || null }) };
      }
      await noteResume(job.jobId, { id: r.body.id, status: r.body.status, title: job.title, company: job.company });
      return { ok: true, model: resumePanelModel({ job, view: r.body, warning: r.body.warning || null }) };
    },

    /** The panel's poll while it generates. */
    RESUME_STATUS: async (msg, sender) => {
      const s = await scope(msg, sender);
      if (s.error) return s.error;
      return { ok: !!s.view, model: resumePanelModel({ job: s.job, view: s.view, error: s.error }) };
    },

    RESUME_CANCEL: async (msg, sender) => {
      const s = await scope(msg, sender);
      if (s.error) return s.error;
      const r = await post(url(), `${viewPath(s.rec.id)}/cancel`);
      const view = r.ok ? r.body : r.body?.generation || s.view;
      if (view?.status) await noteResume(s.job.jobId, { status: view.status });
      return { ok: r.ok, message: r.ok ? null : r.body?.error, model: resumePanelModel({ job: s.job, view }) };
    },

    /**
     * Attach: ⛔ only a generation the server says is READY (asked now). The page is probed for a résumé upload first;
     * then the server stores the PDF as this application's (attach: true), the bytes come from draft's server, and the
     * page's control is set and VERIFIED. Not verified → the fallback, with the bytes for Download PDF.
     */
    RESUME_ATTACH: async (msg, sender) => {
      const s = await scope(msg, sender);
      if (s.error) return s.error;
      // ⭐ (lane e2e-apply, 11-05) "Attach tailored" for a résumé the WEB APP made (the review row learnt it from the
      // server: resumeFilesFor). The extension holds no generation for it yet, so the click asks the server to REUSE
      // that version — `reuseOnly`: it never queues a model call or spends a slot (nothing to reuse → refused).
      // Through the ONE start (RESUME_GENERATE), with `reuseOnly`, so it is still the one place that POSTs a start.
      if (s.view?.status !== 'ready' && msg?.reuse === true && msg?.trigger === 'click') {
        const g = await api.RESUME_GENERATE({ type: 'RESUME_GENERATE', trigger: 'click', reuseOnly: true }, sender);
        const again = g?.ok ? await scope({}, sender) : null;
        if (!again || again.error || again.view?.status !== 'ready') {
          return { ok: false, message: g?.message || 'There is no tailored résumé for this job yet.', model: resumePanelModel({ job: s.job, view: s.view }) };
        }
        s.rec = again.rec;
        s.view = again.view;
      }
      if (s.view?.status !== 'ready') return { ok: false, message: 'Only a ready résumé can be attached.', model: resumePanelModel({ job: s.job, view: s.view }) };
      // ⭐ T18: into the FORM's frame (T11 — Greenhouse's iframe on a company's page), and into the upload the review
      // row names when it was pressed there (`msg.target`).
      const inject = (args) => injectAttach(s.tab.id, { ...args, target: targetOf(msg) });
      let probe;
      try { probe = await inject({ probe: true }); } catch { probe = null; }
      const r = await post(url(), `${viewPath(s.rec.id)}/pdf`, probe?.target ? { attach: true } : {});
      const pdfUrl = r.body?.pdf?.url;
      if (!r.ok || typeof pdfUrl !== 'string' || !pdfUrl.startsWith('/api/extension/resume/')) {
        return { ok: false, message: r.body?.error || 'The PDF could not be made right now.', model: resumePanelModel({ job: s.job, view: s.view }) };
      }
      const fileName = r.body.pdf.fileName;
      const pdf = await fetchPdf(url(), pdfUrl, fileName);
      if (!pdf) return { ok: false, message: 'The PDF could not be fetched right now.', model: resumePanelModel({ job: s.job, view: s.view }) };
      if (!probe?.target) {
        // No upload box on this step (or the page could not be reached): nothing is set — said, with the file to download.
        const attach = { outcome: probe ? 'noinput' : 'fallback', fileName: pdf.fileName, base64: pdf.base64, reason: probe?.reason || 'no_access' };
        return { ok: true, attached: false, attach, model: resumePanelModel({ job: s.job, view: s.view, attach }) };
      }
      let set;
      try { set = await inject({ base64: pdf.base64, fileName: pdf.fileName, mimeType: 'application/pdf' }); } catch { set = { verified: false, reason: 'not_set' }; }
      await noteResume(s.job.jobId, { attached: Date.now() });
      const outcome = set?.verified ? 'attached' : 'fallback';
      const view = { ...s.view, pdf: { ...(s.view.pdf || {}), fileName: pdf.fileName, attached: true } };
      // ⭐ `attach` beside the model, as RESUME_ATTACH_FILE answers: the review row's résumé upload reads the outcome from
      // it (the model is the Résumé tab's — its state, not an attach). Without it a tailored attach that LANDED was
      // called "Could not attach" on the row (open item 5, measured in a real Chrome).
      const attach = { outcome, fileName: pdf.fileName, reason: set?.reason || null, ...(outcome === 'fallback' ? { base64: pdf.base64 } : {}) };
      return { ok: true, attached: outcome === 'attached', how: set?.how || null, attach,
        model: resumePanelModel({ job: s.job, view, attach }) };
    },

    /**
     * ⭐ T18 · "Attach my résumé" on the review row's résumé upload: the account's BASE résumé, as draft renders it
     * (GET /api/extension/base-resume/pdf/file — no model, no Draft slot), set on THAT upload in the form's frame by the
     * same attachResumeFile and VERIFIED; when the page does not show its name, the bytes come back for Download PDF.
     * ⛔ The click's own message only (`trigger: 'click'`, from the page's tab). `which: 'letter'` — draft keeps no cover
     * letter the extension can reach yet, so it is said, and nothing is attached.
     */
    RESUME_ATTACH_FILE: async (msg, sender) => {
      if (msg?.trigger !== 'click') return refuse('A file is attached only from its button.');
      const tab = tabOf(sender);
      if (!tab) return refuse('Attach it from the review panel on the application page.');
      if (!url()) return refuse('Not configured.');
      if (msg.which !== 'base') return refuse('draft holds no cover letter for this job — attach one on the page.');
      const target = targetOf(msg);
      let probe;
      try { probe = await injectAttach(tab.id, { probe: true, target }); } catch { probe = null; }
      const pdf = await fetchPdf(url(), BASE_RESUME_PDF, 'Resume.pdf');
      if (!pdf) return refuse('Your résumé could not be fetched — add one in draft, or attach it on the page yourself.');
      if (!probe?.target) return { ok: true, attached: false, attach: { outcome: 'fallback', fileName: pdf.fileName, base64: pdf.base64, reason: probe?.reason || 'no_access' } };
      let set;
      try { set = await injectAttach(tab.id, { base64: pdf.base64, fileName: pdf.fileName, mimeType: 'application/pdf', target }); } catch { set = { verified: false, reason: 'not_set' }; }
      const outcome = set?.verified ? 'attached' : 'fallback';
      return { ok: true, attached: outcome === 'attached', how: set?.how || null,
        attach: { outcome, fileName: pdf.fileName, reason: set?.reason || null, ...(outcome === 'fallback' ? { base64: pdf.base64 } : {}) } };
    },

    /** Download PDF (the fallback, or any time once ready): the stored PDF's bytes and name. */
    RESUME_DOWNLOAD: async (msg, sender) => {
      const s = await scope(msg, sender);
      if (s.error) return s.error;
      if (s.view?.status !== 'ready') return refuse('Only a ready résumé can be downloaded.');
      const r = await post(url(), `${viewPath(s.rec.id)}/pdf`, {});
      const pdfUrl = r.body?.pdf?.url;
      if (!r.ok || typeof pdfUrl !== 'string' || !pdfUrl.startsWith('/api/extension/resume/')) return refuse(r.body?.error || 'The PDF could not be made right now.');
      const pdf = await fetchPdf(url(), pdfUrl, r.body.pdf.fileName);
      return pdf ? { ok: true, base64: pdf.base64, fileName: pdf.fileName } : refuse('The PDF could not be fetched right now.');
    },

    /**
     * ⭐ D99 · "Read this page now" — the unlinked panel's button (a trusted click on the page). ⭐ BINDING FIRST (owner
     * 10-15): the same IDENTIFY → BIND every press runs (identify.js identifyAndBind — the address, the embedded ATS form's
     * address, then the page's text through the capture's matcher), and only then is the panel drawn for the job it
     * found. A page that names no job of yours binds nothing and says which case it is, in that outcome's own sentence.
     */
    RESUME_READ_PAGE: async (msg, sender) => {
      if (msg?.trigger !== 'click') return refuse('The page is read only from its button.');
      const tab = tabOf(sender);
      if (!tab) return refuse('Read the page from the panel on it.');
      if (!url()) return refuse('Not configured.');
      const pageUrl = String(tab.url || '').slice(0, 2048);
      // ⭐ T32: a read that throws is a script error with its own code — never the generic "couldn't tell"
      const id = await identifyAndBind(tab, { serverUrl: url() })
        .catch(() => ({ outcome: 'script_error', bind: false, job: null, action: 'retry', message: 'Something went wrong reading this page — nothing was read.', lookup: null }));
      const page = id?.lookup || null;
      const job = await jobOfTab(tab);
      notePageRead(tab.id, { url: pageUrl, known: !!job, jobId: job?.jobId ?? null, how: page?.posting?.how || null,
        pageKey: null, basis: page?.basis || null, atsState: page?.ats?.state || null });
      if (!job) {
        const report = page?.basis === 'page' && page.ats ? { ...page.ats, basis: 'page' } : null;
        return { ok: false, code: id?.outcome || 'script_error', message: id?.message || "draft couldn't tell which job this is.",
                 popup: readFailurePopup(id), model: await withAtsComponent(tab, resumePanelModel({ report })) };
      }
      const { view, error } = await currentView(url(), job);
      const allowance = !view ? await allowanceNow(url()) : null;
      return { ok: true, model: await withAtsComponent(tab, resumePanelModel({ job, view, allowance, error, report: await reportFor(job) })) };
    },

    /** The report's "Full report in draft" (the job in the web app) or "Add your résumé in draft" (job profiles). */
    RESUME_OPEN_REPORT: async (msg, sender) => {
      const tab = tabOf(sender);
      if (!tab) return refuse('Open the résumé panel on the application page.');
      if (!url()) return refuse('Not configured.');
      let path = '/app/job-profiles';
      if (msg?.to === 'report') {
        const job = await jobOfTab(tab);
        if (!job) return refuse('This tab is not linked to a job.');
        const found = await lookupBoardJob(url(), job.jobId);
        path = found.ok && found.job.reportPath ? found.job.reportPath : `/app/jobs?job=${encodeURIComponent(job.jobId)}`;
      }
      try { await chrome.tabs.create({ url: `${url()}${path}` }); return { ok: true }; } catch { return refuse('Could not open draft.'); }
    },

    /**
     * ⭐ 47a (owner 11-21, E1) · the ATS tab's plausibility flags (D192 (4d)): the base résumé's bullets that don't line up
     * with what draft knows about their employers — warnings, never in the number. Read only for the panel on a web page's
     * tab; the answer is the server's named words (routes/extensionJob.js flagsForExtension), kept to them again here.
     */
    RESUME_FLAGS: async (_msg, sender) => {
      if (!tabOf(sender)) return refuse('Open the ATS tab on the job page.');
      if (!url()) return refuse('Not configured.');
      const r = await json(url(), '/api/extension/plausibility');
      if (!r.ok) return { ok: false, flags: [] };
      const s = (x, n) => (typeof x === 'string' ? x.slice(0, n) : '');
      return { ok: true, dismissed: Number(r.body?.dismissed) || 0,
        flags: (Array.isArray(r.body?.flags) ? r.body.flags : []).slice(0, 12).map(f => ({ key: s(f.key, 400), company: s(f.company, 80), bullet: s(f.bullet, 160), reason: s(f.reason, 200) })).filter(f => f.key) };
    },
    /** Dismiss — the person's own click on the flag, from the panel; kept across re-scores (the server's record). */
    RESUME_FLAG_DISMISS: async (msg, sender) => {
      if (msg?.trigger !== 'click') return refuse('A flag is dismissed only from its button.');
      if (!tabOf(sender)) return refuse('Open the ATS tab on the job page.');
      if (!url()) return refuse('Not configured.');
      const key = typeof msg.key === 'string' ? msg.key.slice(0, 400) : '';
      if (!key) return refuse('That flag is not known.');
      const r = await post(url(), '/api/extension/plausibility/dismiss', { key, ...(msg.undo === true ? { undo: true } : {}) });
      return r.ok ? { ok: true, dismissed: r.body?.dismissed !== false } : refuse('Could not dismiss it right now.');
    },

    /** Edit in a full page: the server's openUrl for this job, on draft's own site, in a new tab. */
    RESUME_OPEN_EDITOR: async (msg, sender) => {
      const s = await scope(msg, sender);
      if (s.error) return s.error;
      const path = s.view?.openUrl;
      if (typeof path !== 'string' || !path.startsWith('/') || path.startsWith('//')) return refuse('Could not open draft.');
      try { await chrome.tabs.create({ url: `${url()}${path}` }); return { ok: true }; } catch { return refuse('Could not open draft.'); }
    },
  };
  return api;
}

/** The contract the wiring guide names: one object of handlers, bound to the configured server URL. */
export const handlers = handlersFor();
