import {
  runGatedHandoff, clearPacketForTab, sweepExpiredPackets, applyOverlayEdit,
  loadBatchForTab, clearBatchForTab, portalQueueFor,
  prepareAndFill, recordSubmitted, copySheetFor, pageMatchFor, packetFillsOrigin,
} from './gated-handoff.js';
import { extractJobPayload, showCaptureToast } from './extractor.js';
import { authedFetch, getIdentity, cachedIdentity, disconnect } from './auth.js';
import { captureResultFrom } from './captureResult.js';
import {
  CONTEXT_MENUS, MENU_SAVE_PAGE, MENU_SAVE_LINK, saveableLink, reportHostOf, buildFormReport, collectFormLabels,
} from './formReport.js';
// D23: the site's colour tokens, generated from client/src/styles/colorTokens.js — the toolbar badge
// and the capture toast take their colours from here, never from a literal.
import { C_LIGHT, C_DARK } from './tokens.js';
import {
  AUTO_CAPTURE_SETTING, AUTO_CAPTURE_ORIGINS, autoCaptureOriginFor, autoCaptureStep, pageHasJobPosting, createSeenSet,
  setAutoCaptureSetting,
} from './autoCapture.js';

// Keep in sync with config.js (service workers cannot share plain-script globals).
// DEV SWITCH: comment line A, uncomment line B.
const RESUME_MASTER_URL = 'https://jobsviadraft.com'; // A: production
// const RESUME_MASTER_URL = 'http://localhost:3000'; // B: local dev

// ── Capture (E2) ─────────────────────────────────────────────────────────────
// THE ONE NETWORK PATH FOR CAPTURE, and it lives in the service worker rather than the content
// script for a reason that only shows up in production.
//
// A content script's fetch carries the PAGE's origin — https://www.linkedin.com — not the
// extension's. server.js's corsOrigin admits only APP_BASE_ORIGIN/FRONTEND_ORIGIN in production, and
// corsOriginExtension additionally admits chrome-extension:// but not a job board either. So every
// capture posted from the content script would be refused by CORS the moment NODE_ENV=production —
// invisible in development, where corsOrigin returns true for everything.
//
// A service worker fetch is not subject to CORS for a host in host_permissions, and
// https://jobsviadraft.com/* is declared. Moving the call here fixes it without widening the
// server's CORS to six job boards, which is the alternative and a far worse trade.
async function importCapturedJob({ url, text }) {
  try {
    // authedFetch, not a bare credentialed fetch: the extension acts as its OWN token, never as
    // whatever session the browser holds. See extension/auth.js.
    const res = await authedFetch(RESUME_MASTER_URL, '/api/import/job', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ url, text }),
    });

    // null means there is no credential to be had — no session to bootstrap from, so the remedy
    // is signing in on the website, not retrying here.
    if (!res) return captureResultFrom(401, {}, RESUME_MASTER_URL);
    const json = await res.json().catch(() => ({}));
    // ⛔ D33: the server's capture object says what happened — added · already on the board (with a
    // link to that posting) · held off the board and WHY · closed — and the toast and popup show
    // exactly that. A 2xx that says nothing is not reported as a capture. needsClientCapture (should
    // not happen: the extracted text is always sent) is reported, not swallowed — captureResult.js.
    return captureResultFrom(res.status, json, RESUME_MASTER_URL);
  } catch (e) {
    return { success: false, outcome: null, onBoard: false, message: 'Could not reach draft', link: null, jobId: null };
  }
}

// ── THE capture implementation. One function, every trigger. ─────────────────
//
// Extraction is INJECTED rather than delivered by a content script, and that is the whole design.
// A content script needs a host permission for every origin it runs on, so capture only ever worked
// on the six boards the manifest happened to name — never on a Greenhouse board embedded at
// stripe.com/jobs, never on Ashby, never on a company careers page. You cannot enumerate every
// employer's domain, so that approach had a ceiling built into it.
//
// activeTab has no such ceiling. The user's invocation — the toolbar click or the hotkey — grants
// access to that one tab, and executeScript reaches it whatever the origin. G0 measured the grant
// on a real Workday tenant with no host permission for it; E6 measured that a toolbar click grants
// it to the popup too. So the extension now asks for NO job-board host permission at all and
// captures more sites than it did with seven.
//
// It also means the extension has no standing access to anything. Before, it could read six sites
// whenever they were open. Now it can read one tab, at the moment you point it at one.
async function captureActiveTab(tab) {
  if (!tab?.id) return { success: false, message: 'No active tab.' };

  // tab.url is only readable once the grant exists, so treat "unreadable" as "not yet granted"
  // rather than as a bad page — the injection below will produce the real error if there is one.
  if (tab.url && !/^https?:$/.test(new URL(tab.url).protocol)) {
    return { success: false, message: 'Only http(s) pages can be captured.' };
  }

  let extracted;
  try {
    const [r] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: extractJobPayload });
    extracted = r?.result;
  } catch (e) {
    // The grant is missing or lapsed — Chrome revokes it when the tab leaves the origin it was
    // taken on. This is an expected state with a clear remedy, not a failure worth a stack trace.
    return { success: false, message: 'Press the shortcut again on the job page you want to capture.' };
  }

  if (!extracted?.ok) {
    const miss = { success: false, message: 'No job found on this page' };
    await reportCapture(tab.id, miss);
    return miss;
  }

  const result = await importCapturedJob({ url: extracted.url, text: extracted.text });
  await reportCapture(tab.id, result);
  return result;
}

// The toast's colours, both palettes: it is injected into the page and picks one by the page's
// prefers-color-scheme. Text on a solid state fill is SURFACE_SOLID — the sanctioned pairing in
// colorTokens.js's CONTRAST_PAIRS (["SURFACE_SOLID", "SUCCESS"], ["SURFACE_SOLID", "DANGER"]).
function toastTheme() {
  const pick = (c) => ({ ok: c.SUCCESS, fail: c.DANGER, text: c.SURFACE_SOLID, shadow: c.SHADOW_MD });
  return { light: pick(C_LIGHT), dark: pick(C_DARK) };
}

/** Same feedback for every trigger: the toast in the page, and the record the popup reads later. */
async function reportCapture(tabId, result) {
  try {
    await chrome.scripting.executeScript({
      target: { tabId }, func: showCaptureToast, args: [result.message, !!result.success, toastTheme()],
    });
  } catch (_) { /* the toast is a courtesy; never let it change the outcome */ }
  // Recorded so the popup can show the outcome of a hotkey capture it was not open for.
  chrome.storage.local.set({ lastCapture: { ...result, at: Date.now() } }).catch(() => {});
}

/**
 * D13 — the page's context for the companion popup, from two reads the server already answers:
 *   · POST /api/import/context      — is this posting on your board, what ATS the URL names, your
 *                                     recent captures
 *   · portalQueueFor(origin)         — the applications you DRAFTED whose form lives at this origin
 *                                     (gate-packets?origin=), with their counts — never their answers
 * Either can fail on its own; the popup then falls back to showing every action.
 */
async function popupContext(tab) {
  let url = '';
  let origin = '';
  try { const u = new URL(tab?.url || ''); if (/^https?:$/.test(u.protocol)) { url = u.href; origin = u.origin; } }
  catch { /* chrome://, file:// or a blank tab: no page context, recent captures only */ }
  const [board, queue] = await Promise.all([
    authedFetch(RESUME_MASTER_URL, '/api/import/context', {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ url }),
    })
      .then(r => (r && r.ok ? r.json() : null)).catch(() => null),
    // D56: which packets may fill THIS page (origin list + job id), or which case it is — and the
    // on-demand company notice (§8 row 10). Asked only on the press, like the rest of this.
    origin ? pageMatchFor(RESUME_MASTER_URL, tab) : Promise.resolve(null),
  ]);
  return {
    url, origin,
    posting: board?.posting || null,
    ats: board?.ats || null,
    recent: board?.recent || [],
    packets: (queue?.packets || []).map(p => ({
      packetId: p.packetId, title: p.title, company: p.company, createdAt: p.createdAt, stale: !!p.stale,
      answerCount: p.answerCount ?? 0, unresolvedCount: p.unresolvedCount ?? 0, resumeAvailable: !!p.resumeAvailable,
      gateReason: p.gateReason || null,
      // D63: the job card and the packet summary — two scores and a logo address, nothing more.
      scores: p.scores || null, logo: p.logo || null,
    })),
    handoff: queue ? { state: queue.state || null, message: queue.message || null, canPrepare: !!queue.canPrepare,
                       job: queue.job || null, resume: queue.resume || null } : null,
    notice: queue?.notice || null,
  };
}

/** What the popup shows once you press "Read this page" (D23). Same extractor, no network, no writes. */
async function previewActiveTab(tab) {
  const capturable = !!tab?.id && (!tab.url || /^https?:$/.test(new URL(tab.url).protocol));
  if (!capturable) return { capturable: false };
  try {
    const [r] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: extractJobPayload });
    const p = r?.result;
    return { capturable: true, ok: !!p?.ok, title: p?.title || '', company: p?.company || '', location: p?.location || '' };
  } catch (_) {
    // No grant yet. The button still shows: clicking it is itself an invocation, and the capture
    // that follows will succeed where this speculative read could not.
    return { capturable: true, ok: false, unreadable: true };
  }
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  // Capture, from the popup button. The hotkey reaches the same function through onCommand below;
  // neither trigger has an implementation of its own.
  if (message.type === 'CAPTURE_ACTIVE_TAB') {
    chrome.tabs.query({ active: true, currentWindow: true })
      .then(([tab]) => captureActiveTab(tab))
      .then(sendResponse);
    return true;                                            // async response
  }

  // D64 · the popup's "Captured today", and its undo — asked when the popup opens its list.
  if (message.type === 'AUTO_CAPTURES') {
    authedFetch(RESUME_MASTER_URL, '/api/import/auto')
      .then(r => (r ? r.json() : null)).then(sendResponse).catch(() => sendResponse(null));
    return true;
  }
  if (message.type === 'AUTO_CAPTURE_UNDO' && message.jobId) {
    authedFetch(RESUME_MASTER_URL, `/api/import/auto/${encodeURIComponent(message.jobId)}/undo`, { method: 'POST' })
      .then(r => (r ? r.json() : null)).then(sendResponse).catch(() => sendResponse(null));
    return true;
  }

  if (message.type === 'PREVIEW_ACTIVE_TAB') {
    chrome.tabs.query({ active: true, currentWindow: true })
      .then(([tab]) => previewActiveTab(tab))
      .then(sendResponse);
    return true;
  }

  // D13, THE COMPANION — what the popup needs to pick the right action for this page. ⛔ D23: asked
  // only when the user PRESSES "Read this page" in the popup (or its R key) — never on popup open —
  // and never stored: no storage key is added, so the listing's six are unchanged. See popupContext().
  if (message.type === 'POPUP_CONTEXT') {
    chrome.tabs.query({ active: true, currentWindow: true })
      .then(([tab]) => popupContext(tab))
      .then(sendResponse)
      .catch(() => sendResponse(null));
    return true;
  }

  // D13: "Fill it" from the popup — the SAME handoff Ctrl+Shift+Y runs (one implementation, two
  // triggers, as capture already is). Opening the popup is the gesture that grants activeTab.
  if (message.type === 'FILL_ACTIVE_TAB') {
    handleGatedHandoff()
      // D36: whether the review panel opened travels with the answer, so the popup can stay open when it did not.
      .then(r => sendResponse({ ok: !!r?.ok, message: r?.message || null, overlay: r?.overlay ? { rendered: r.overlay.rendered === true } : null,
        reason: r?.reason || null, canPrepare: !!r?.canPrepare }))
      .catch(() => sendResponse({ ok: false, message: 'Could not fill this page.' }));
    return true;
  }

  // ⭐ D56 · "Prepare this application" — one click builds the packet on demand, then the same handoff
  // fills it. The popup's click is the gesture that grants activeTab.
  if (message.type === 'PREPARE_ACTIVE_TAB') {
    chrome.tabs.query({ active: true, currentWindow: true })
      .then(async ([tab]) => { const r = await prepareAndFill({ serverUrl: RESUME_MASTER_URL, tab }); await reportHandoff(tab, r); return r; })
      .then(r => sendResponse({ ok: !!r?.ok, message: r?.message || null, reason: r?.reason || null,
        overlay: r?.overlay ? { rendered: r.overlay.rendered === true } : null }))
      .catch(() => sendResponse({ ok: false, message: 'Could not prepare this application.' }));
    return true;
  }

  // ⭐ D56 · "I submitted" from the popup — recorded against the page in view, which is the evidence.
  if (message.type === 'SUBMITTED_ACTIVE_TAB') {
    chrome.tabs.query({ active: true, currentWindow: true })
      .then(([tab]) => recordSubmitted({ serverUrl: RESUME_MASTER_URL, tab }))
      .then(sendResponse)
      .catch(() => sendResponse({ ok: false, message: 'Could not record it.' }));
    return true;
  }

  // ⭐ §8 row 17 · the Copy sheet — the prepared answers, for the popup to list. Nothing enters the page.
  if (message.type === 'COPY_SHEET') {
    chrome.tabs.query({ active: true, currentWindow: true })
      .then(([tab]) => copySheetFor({ serverUrl: RESUME_MASTER_URL, tab }))
      .then(sendResponse)
      .catch(() => sendResponse({ ok: false, rows: [] }));
    return true;
  }

  // ⭐ §8 row 15, decision D · THE TODAY RING — today's Drafts and new résumés against the user's CAP
  // (the day's Draft slots, services/draftSlots.js), never a goal. It asks about the ACCOUNT, not the
  // page: no tab, no URL, nothing read — so it is allowed on popup open (D23's rule is about the page).
  if (message.type === 'TODAY_RING') {
    authedFetch(RESUME_MASTER_URL, '/api/draft/slots')
      .then(r => (r && r.ok ? r.json() : null))
      .then(s => sendResponse(s ? { limit: s.limit, used: s.used, remaining: s.remaining, windowHours: s.windowHours ?? 24 } : null))
      .catch(() => sendResponse(null));
    return true;
  }

  // The popup's auth probe, moved here for the same CORS reason: from the popup this request
  // carries chrome-extension://, which corsOrigin refuses in production.
  if (message.type === 'PROBE_AUTH') {
    getIdentity(RESUME_MASTER_URL)
      .then(id => sendResponse(id))
      .catch(() => sendResponse({ authenticated: false }));
    return true;
  }

  // WHO THE EXTENSION IS ACTING AS. The popup must be able to name it — an extension that acts
  // with an identity the user cannot see is the defect this whole change exists to remove.
  // Answers from cache first so the popup can paint immediately, then the popup re-asks.
  if (message.type === 'GET_IDENTITY') {
    (message.fresh
      ? getIdentity(RESUME_MASTER_URL)
      : cachedIdentity().then(c => c || getIdentity(RESUME_MASTER_URL))
    ).then(id => sendResponse(id || { authenticated: false }))
     .catch(() => sendResponse({ authenticated: false }));
    return true;
  }

  // Ending the extension's own credential, deliberately. Revokes server-side, then clears locally.
  if (message.type === 'DISCONNECT') {
    disconnect(RESUME_MASTER_URL)
      .then(() => sendResponse({ ok: true }))
      .catch(() => sendResponse({ ok: false }));
    return true;
  }

  // ⛔ THESE TWO PATHS WERE NEVER ROUTES. `/ats-score` and `/resume` both fell through to the
  // client's catch-all, which redirects an authenticated ADMIN to /admin — the whole "the resume
  // builder opened an admin session" report (docs/EXTENSION_DIAGNOSIS.md §4). The real pages are
  // /tools/ats and /tools/generate.
  //
  // The server-side aliases added alongside this keep the OLD paths working for every copy of
  // v1.0.0 already installed, because this file only reaches users after a Web Store update. Both
  // halves are deliberate: the alias fixes today, this fixes the next build.
  if (message.type === 'OPEN_ATS_SCORE') {
    const encoded = encodeURIComponent((message.jobText || '').slice(0, 5000));
    chrome.tabs.create({ url: `${RESUME_MASTER_URL}/tools/ats?jd=${encoded}` });
    sendResponse({ success: true });
    return true;
  }

  if (message.type === 'OPEN_LINKEDIN_IMPORT') {
    chrome.tabs.create({ url: `${RESUME_MASTER_URL}/auth/linkedin` });
    sendResponse({ success: true });
    return true;
  }

  if (message.type === 'OPEN_RESUME_BUILDER') {
    // /tools/generate is the standalone resume generator. There is no separate "resume builder"
    // surface in the client and there never was, which is why /resume could not have worked.
    chrome.tabs.create({ url: `${RESUME_MASTER_URL}/tools/generate` });
    sendResponse({ success: true });
    return true;
  }

  return true;
});

// The hotkey. chrome://extensions/shortcuts owns the binding, and that is now the only way to
// rebind it: the old page-scoped keydown override lived in the content script, which no longer
// exists. Chrome's own rebinding UI works on every page rather than only the six the content
// script reached, so this is a smaller extension doing more.
//
// THE LISTENER FIRING IS THE PERMISSION. A chrome.commands invocation is a user gesture, which is
// what grants activeTab for the tab they are on — the same grant the gated handoff runs on.
chrome.commands.onCommand.addListener((command) => {
  if (command === 'fill-gated-application') { void handleGatedHandoff(); return; }
  if (command !== 'capture-job') return;
  chrome.tabs.query({ active: true, currentWindow: true }, ([tab]) => { void captureActiveTab(tab); });
});

// ── Gated portal handoff (TASK G2) ───────────────────────────────────────────
// THIS LISTENER FIRING IS THE PERMISSION. A chrome.commands invocation is a user gesture, which is
// what grants activeTab for the tab they are on — there is no host permission for portal origins and
// there must never be. Everything else follows from that one grant.
//
// The result is reported with chrome.action's badge rather than a notification: the extension has no
// `notifications` permission, and adding one for a status message would be a new user-facing consent
// prompt for something a badge already says.
async function handleGatedHandoff() {
  void sweepExpiredPackets();
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const result = await runGatedHandoff({ serverUrl: RESUME_MASTER_URL, tab });
  await reportHandoff(tab, result);
  return result;
}

async function reportHandoff(tab, result) {
  const badge = result.ok ? { text: String(result.filled?.length ?? 0), color: C_LIGHT.SUCCESS }
                          : { text: '!', color: C_LIGHT.DANGER };
  try {
    await chrome.action.setBadgeText({ tabId: tab?.id, text: badge.text });
    await chrome.action.setBadgeBackgroundColor({ tabId: tab?.id, color: badge.color });
    await chrome.action.setTitle({ tabId: tab?.id, title: result.message || 'draft' });
  } catch { /* a tab that closed mid-handoff is not an error worth surfacing */ }

  // Stored so the popup, and the verification harnesses, can see the detail a badge cannot.
  try {
    await chrome.storage.session.set({ lastGatedHandoff: { ...result, at: Date.now(), tabId: tab?.id } });
  } catch { /* session storage is best-effort here */ }
}

// ── Review overlay traffic (TASK G3) ─────────────────────────────────────────
// The overlay runs in the page's isolated world and talks back through here. Two messages: a
// corrected value, and the running readiness state.
//
// Kept OUT of the onMessage listener above, which answers synchronously; these need to await.
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg?.type === 'GATE_REVIEW_EDIT') {
    const tabId = sender.tab?.id;
    if (!tabId) { sendResponse({ ok: false, reason: 'no_tab' }); return true; }
    applyOverlayEdit({ tabId, field: msg.field, value: msg.value })
      .then(result => sendResponse({ ok: true, result }))
      .catch(e => sendResponse({ ok: false, reason: e.message }));
    return true;                                            // async response
  }

  // ── One gate crossing, several applications (TASK G5) ─────────────────────
  // Moves the SAME TAB to the next application on this portal. G0 measured that the activeTab grant
  // survives every same-origin navigation, browser-initiated ones included, so this costs no second
  // gesture — which is the entire point of amortising per portal rather than per application.
  if (msg?.type === 'GATE_BATCH_NEXT') {
    const tabId = sender.tab?.id;
    if (!tabId) { sendResponse({ ok: false, reason: 'no_tab' }); return true; }
    advanceBatch(tabId).then(r => sendResponse(r)).catch(e => sendResponse({ ok: false, reason: e.message }));
    return true;
  }

  // D56: "I submitted it" in the review overlay — the overlay's own tab is the page recorded.
  if (msg?.type === 'GATE_SUBMITTED') {
    if (!sender.tab?.id) { sendResponse({ ok: false, message: 'No tab.' }); return true; }
    recordSubmitted({ serverUrl: RESUME_MASTER_URL, tab: sender.tab })
      .then(r => sendResponse(r)).catch(() => sendResponse({ ok: false, message: 'Could not record it.' }));
    return true;
  }

  if (msg?.type === 'GATE_REVIEW_STATE') {
    // Recorded against the application's audit row: for a gated application this is the ONLY record
    // of what a human saw before it went out, because the submission happens in a browser we never
    // observe. Best-effort — a failure here must never block the candidate from submitting.
    void recordGateReview(sender.tab?.id, msg);
    sendResponse({ ok: true });
    return true;
  }
  return false;
});

async function recordGateReview(tabId, msg) {
  if (!tabId) return;
  const stored = await chrome.storage.session.get(`gate:${tabId}`);
  const entry = stored?.[`gate:${tabId}`];
  const runJobId = entry?.packet?.runJobId;
  if (!runJobId) return;
  try {
    await authedFetch(RESUME_MASTER_URL, '/api/apply/gate-review', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        runJobId,
        packetId: entry.packetId ?? null,
        ready: !!msg.ready,
        acknowledged: msg.acknowledged || [],
        edits: msg.edits || [],
      }),
    });
  } catch { /* the candidate's submission does not depend on our bookkeeping */ }
}

async function advanceBatch(tabId) {
  const batch = await loadBatchForTab(tabId);
  if (!batch?.origin) return { ok: false, reason: 'no_batch' };

  // Re-read the queue rather than trusting the count the overlay was rendered with: the candidate may
  // have finished one of these in another tab since.
  // Scoped to the batch's origin. Unscoped, this list is the newest 100 unconsumed packets across
  // EVERY portal — so a candidate with a long queue could have this batch's packets fall outside
  // the cap entirely, and the filter below would find nothing. That reads as `batch_empty` and
  // stops a run that has work left, which is the worst way for a cap to fail: silently, and as a
  // completion.
  const res = await authedFetch(
    RESUME_MASTER_URL,
    `/api/apply/gate-packets?origin=${encodeURIComponent(batch.origin)}`)
    .catch(() => null);
  if (!res?.ok) return { ok: false, reason: 'unreachable' };
  const body = await res.json();
  const next = (body.packets || [])
    // D56: the packet's origin LIST — a two-origin ATS batches across both of its addresses.
    .filter(p => packetFillsOrigin(p, batch.origin))
    .sort((a, b) => b.createdAt - a.createdAt)[0];
  if (!next) { await clearBatchForTab(tabId); return { ok: false, reason: 'batch_empty' }; }

  // The packet released into THIS tab is finished with; the next application must be matched and
  // approved on its own terms rather than inheriting the last one's.
  await clearPacketForTab(tabId);

  // Two applications can share an apply URL — a portal that serves them all from one route, or a
  // reopened handoff for the job already open. tabs.update to the URL already showing does nothing
  // and fires no onUpdated, so waiting for one would hang the batch here forever. Run it directly.
  const current = await chrome.tabs.get(tabId).catch(() => null);
  if (current?.url === next.applyUrl) {
    const result = await runGatedHandoff({ serverUrl: RESUME_MASTER_URL, tab: current });
    await reportHandoff(current, result);
    return { ok: true, packetId: next.packetId, applyUrl: next.applyUrl, navigated: false };
  }

  await chrome.tabs.update(tabId, { url: next.applyUrl });
  return { ok: true, packetId: next.packetId, applyUrl: next.applyUrl, navigated: true };
}

// The candidate is already authenticated and the grant is still live, so the next application in a
// batch fills without another keypress. Strictly scoped: only a tab with an ACTIVE BATCH, only when
// it lands on the same origin that batch belongs to. Any other navigation is none of our business.
chrome.tabs.onUpdated.addListener(async (tabId, info, tab) => {
  if (info.status !== 'complete') return;
  const batch = await loadBatchForTab(tabId);
  if (!batch?.origin) return;

  // An unreadable URL is not a missing detail, it is the answer: without the tabs permission, a tab's
  // url is visible only while we hold access to it. Losing sight of it means the activeTab grant is
  // gone, which means the tab left the origin — so the batch is over. Treating this as "skip and try
  // again later" is what left a batch pinned to a tab the candidate had navigated away from.
  if (!tab?.url) { await clearBatchForTab(tabId); return; }

  let origin;
  try { origin = new URL(tab.url).origin; } catch { await clearBatchForTab(tabId); return; }
  if (origin !== batch.origin) {
    // Left the portal. The grant is gone (G0 §9) and so is the batch; the remaining jobs stay held
    // rather than being treated as failed — they were never touched.
    await clearBatchForTab(tabId);
    return;
  }
  const result = await runGatedHandoff({ serverUrl: RESUME_MASTER_URL, tab });
  await reportHandoff(tab, result);
});

// ── ⭐ D64 · AUTOMATED CAPTURE ─────────────────────────────────────────────────────────────────────
// A tab finishing a load on one of AUTO_CAPTURE_ORIGINS — only while the user has switched it on AND
// Chrome holds the optional host access they granted — is considered. autoCaptureStep decides with no
// page read; a page whose URL does not say "posting" is checked for JobPosting JSON-LD locally. ⛔ A page
// that is not a posting sends NOTHING. A posting is read with the capture's own extractor and sent to
// /api/import/auto, where the server decides whether it belongs on the user's board (and stores nothing
// if not). No toast: the owner asked for it to happen "without the user having to do anything"; the
// popup lists what was captured today, with an undo. ⛔ Nothing is filled or submitted here (D36).
const autoSeen = createSeenSet();
async function autoCaptureEnabled() {
  try { return !!(await chrome.storage.local.get(AUTO_CAPTURE_SETTING))[AUTO_CAPTURE_SETTING]; } catch { return false; }
}
async function hostGranted(url) {
  const origin = autoCaptureOriginFor(url);
  if (!origin) return false;
  try { return await chrome.permissions.contains({ origins: [origin] }); } catch { return false; }
}
export async function maybeAutoCapture(tab) {
  const url = tab?.url;
  if (!tab?.id || !url || autoSeen.has(url)) return { step: 'skip' };
  const step = autoCaptureStep({ enabled: await autoCaptureEnabled(), url, granted: await hostGranted(url) });
  if (step === 'skip') return { step };
  try {
    if (step === 'check_page') {
      const [probe] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: pageHasJobPosting });
      if (!probe?.result) return { step, posting: false };            // ⛔ not a posting → nothing sent
    }
    const [r] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: extractJobPayload });
    const extracted = r?.result;
    if (!extracted?.ok) return { step, posting: false };
    autoSeen.add(url);
    const res = await authedFetch(RESUME_MASTER_URL, '/api/import/auto', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ url: extracted.url || url, text: extracted.text }),
    });
    if (!res) return { step, sent: false };                             // not signed in: nothing to do
    const json = await res.json().catch(() => ({}));
    return { step, sent: true, status: res.status, discarded: !!json.discarded, already: !!json.already };
  } catch {
    return { step, error: true };
  }
}
chrome.tabs.onUpdated.addListener((tabId, info, tab) => {
  if (info.status !== 'complete') return;
  void maybeAutoCapture(tab);
});
// Switching automatic capture off in Options removes the host access; if the user removes it from
// chrome://extensions instead, the setting follows, so the two never disagree.
chrome.permissions?.onRemoved?.addListener(async (removed) => {
  if ((removed?.origins || []).some(o => AUTO_CAPTURE_ORIGINS.includes(o))) {
    try { await setAutoCaptureSetting(false); } catch { /* storage gone */ }
  }
});

// The packet outlives its activeTab grant (G0 §9 measured this), so nothing expires it on its own.
// A closed tab is the one unambiguous signal that its handoff is over.
chrome.tabs.onRemoved.addListener((tabId) => {
  void clearPacketForTab(tabId);
  void clearBatchForTab(tabId);
});

// And a sweep for the rest: a handoff the candidate walked away from leaves a packet holding a home
// address in session storage until the browser restarts. onStartup/onInstalled plus every invocation
// is enough to keep that bounded without a polling alarm.
chrome.runtime.onStartup?.addListener(() => { void sweepExpiredPackets(); });
chrome.runtime.onInstalled?.addListener(() => { void sweepExpiredPackets(); });

// ── D55 · the right-click menu (decision B) and "Report this form" (decision E) ──────────────
// Everything that is not a chrome.* call lives in formReport.js. Both menu items act only on the
// click itself — a user gesture, which is also what grants activeTab for the clicked tab.
chrome.runtime.onInstalled?.addListener(() => {
  chrome.contextMenus.removeAll(() => {
    for (const item of CONTEXT_MENUS) chrome.contextMenus.create({ ...item });
  });
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  // "Save this page" IS the capture — the same captureActiveTab() the button and Ctrl+Shift+K run.
  if (info.menuItemId === MENU_SAVE_PAGE) { void captureActiveTab(tab); return; }
  if (info.menuItemId === MENU_SAVE_LINK) void saveLinkToDraft(info.linkUrl, tab);
});

/** "Save link to draft": the link's address only — no page is opened or read. The server decides. */
async function saveLinkToDraft(linkUrl, tab) {
  const url = saveableLink(linkUrl);
  let result;
  if (!url) {
    result = { success: false, outcome: null, onBoard: false, message: 'That is not a web link draft can save.', link: null, jobId: null };
  } else {
    try {
      const res = await authedFetch(RESUME_MASTER_URL, '/api/import/link', {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ url }),
      });
      result = res
        ? captureResultFrom(res.status, await res.json().catch(() => ({})), RESUME_MASTER_URL)
        : captureResultFrom(401, {}, RESUME_MASTER_URL);
    } catch {
      result = { success: false, outcome: null, onBoard: false, message: 'Could not reach draft', link: null, jobId: null };
    }
  }
  // The same toast and the same lastCapture record a capture leaves — no new storage key.
  if (tab?.id) await reportCapture(tab.id, result);
  return result;
}

// "Report this form", from the popup. Two steps, both the user's: PREVIEW reads the labels (the popup
// shows the host and how many labels before anything is sent); SEND reads them again and posts
// host + labels. The page is re-read rather than the preview trusted, so nothing the popup holds
// can widen what is sent — buildFormReport() emits only host, labels, fieldCount and the version.
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg?.type !== 'REPORT_FORM') return false;
  (async () => {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    const host = reportHostOf(tab?.url);
    if (!tab?.id || !host) return { ok: false, message: 'Open the application form you want to report.' };
    let collected;
    try {
      const [r] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: collectFormLabels });
      collected = r?.result;
    } catch {
      return { ok: false, message: 'Open the popup again on the form page, then report it.' };
    }
    const report = buildFormReport({ host, collected, version: chrome.runtime.getManifest?.().version });
    if (!report.labels.length) return { ok: false, message: 'No form fields were found on this page.' };
    if (msg.phase !== 'send') return { ok: true, preview: true, host: report.host, labelCount: report.labels.length };
    const res = await authedFetch(RESUME_MASTER_URL, '/api/form-reports', {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(report),
    }).catch(() => null);
    if (!res) return { ok: false, message: 'Sign in to draft first.' };
    const body = await res.json().catch(() => ({}));
    if (!res.ok) return { ok: false, message: body.message || 'Could not send the report.' };
    return { ok: true, sent: true, host: report.host, labelCount: report.labels.length };
  })().then(sendResponse, () => sendResponse({ ok: false, message: 'Could not send the report.' }));
  return true;
});
